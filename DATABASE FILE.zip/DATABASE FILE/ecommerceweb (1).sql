-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 29-11-2025 a las 07:55:30
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `ecommerceweb`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_color`
--

CREATE TABLE `tbl_color` (
  `color_id` int(11) NOT NULL,
  `color_name` varchar(191) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Volcado de datos para la tabla `tbl_color`
--

INSERT INTO `tbl_color` (`color_id`, `color_name`) VALUES
(1, 'Red'),
(2, 'Black'),
(3, 'Blue'),
(4, 'Yellow'),
(5, 'Green'),
(6, 'White'),
(7, 'Orange'),
(8, 'Brown'),
(9, 'Tan'),
(10, 'Pink'),
(11, 'Mixed'),
(12, 'Lightblue'),
(13, 'Violet'),
(14, 'Light Purple'),
(15, 'Salmon'),
(16, 'Gold'),
(17, 'Gray'),
(18, 'Ash'),
(19, 'Maroon'),
(20, 'Silver'),
(21, 'Dark Clay'),
(22, 'Cognac'),
(23, 'Coffee'),
(24, 'Charcoal'),
(25, 'Navy'),
(26, 'Fuchsia'),
(27, 'Olive'),
(28, 'Burgundy'),
(29, 'Midnight Blue');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_country`
--

CREATE TABLE `tbl_country` (
  `country_id` int(11) NOT NULL,
  `country_name` varchar(100) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci ROW_FORMAT=DYNAMIC;

--
-- Volcado de datos para la tabla `tbl_country`
--

INSERT INTO `tbl_country` (`country_id`, `country_name`) VALUES
(1, 'Afghanistan'),
(2, 'Albania'),
(3, 'Algeria'),
(4, 'American Samoa'),
(5, 'Andorra'),
(6, 'Angola'),
(7, 'Anguilla'),
(8, 'Antarctica'),
(9, 'Antigua and Barbuda'),
(10, 'Argentina'),
(11, 'Armenia'),
(12, 'Aruba'),
(13, 'Australia'),
(14, 'Austria'),
(15, 'Azerbaijan'),
(16, 'Bahamas'),
(17, 'Bahrain'),
(18, 'Bangladesh'),
(19, 'Barbados'),
(20, 'Belarus'),
(21, 'Belgium'),
(22, 'Belize'),
(23, 'Benin'),
(24, 'Bermuda'),
(25, 'Bhutan'),
(26, 'Bolivia'),
(27, 'Bosnia and Herzegovina'),
(28, 'Botswana'),
(29, 'Bouvet Island'),
(30, 'Brazil'),
(31, 'British Indian Ocean Territory'),
(32, 'Brunei Darussalam'),
(33, 'Bulgaria'),
(34, 'Burkina Faso'),
(35, 'Burundi'),
(36, 'Cambodia'),
(37, 'Cameroon'),
(38, 'Canada'),
(39, 'Cape Verde'),
(40, 'Cayman Islands'),
(41, 'Central African Republic'),
(42, 'Chad'),
(43, 'Chile'),
(44, 'China'),
(45, 'Christmas Island'),
(46, 'Cocos (Keeling) Islands'),
(47, 'Colombia'),
(48, 'Comoros'),
(49, 'Congo'),
(50, 'Cook Islands'),
(51, 'Costa Rica'),
(52, 'Croatia (Hrvatska)'),
(53, 'Cuba'),
(54, 'Cyprus'),
(55, 'Czech Republic'),
(56, 'Denmark'),
(57, 'Djibouti'),
(58, 'Dominica'),
(59, 'Dominican Republic'),
(60, 'East Timor'),
(61, 'Ecuador'),
(62, 'Egypt'),
(63, 'El Salvador'),
(64, 'Equatorial Guinea'),
(65, 'Eritrea'),
(66, 'Estonia'),
(67, 'Ethiopia'),
(68, 'Falkland Islands (Malvinas)'),
(69, 'Faroe Islands'),
(70, 'Fiji'),
(71, 'Finland'),
(72, 'France'),
(73, 'France, Metropolitan'),
(74, 'French Guiana'),
(75, 'French Polynesia'),
(76, 'French Southern Territories'),
(77, 'Gabon'),
(78, 'Gambia'),
(79, 'Georgia'),
(80, 'Germany'),
(81, 'Ghana'),
(82, 'Gibraltar'),
(83, 'Guernsey'),
(84, 'Greece'),
(85, 'Greenland'),
(86, 'Grenada'),
(87, 'Guadeloupe'),
(88, 'Guam'),
(89, 'Guatemala'),
(90, 'Guinea'),
(91, 'Guinea-Bissau'),
(92, 'Guyana'),
(93, 'Haiti'),
(94, 'Heard and Mc Donald Islands'),
(95, 'Honduras'),
(96, 'Hong Kong'),
(97, 'Hungary'),
(98, 'Iceland'),
(99, 'India'),
(100, 'Isle of Man'),
(101, 'Indonesia'),
(102, 'Iran (Islamic Republic of)'),
(103, 'Iraq'),
(104, 'Ireland'),
(105, 'Israel'),
(106, 'Italy'),
(107, 'Ivory Coast'),
(108, 'Jersey'),
(109, 'Jamaica'),
(110, 'Japan'),
(111, 'Jordan'),
(112, 'Kazakhstan'),
(113, 'Kenya'),
(114, 'Kiribati'),
(115, 'Korea, Democratic People\'s Republic of'),
(116, 'Korea, Republic of'),
(117, 'Kosovo'),
(118, 'Kuwait'),
(119, 'Kyrgyzstan'),
(120, 'Lao People\'s Democratic Republic'),
(121, 'Latvia'),
(122, 'Lebanon'),
(123, 'Lesotho'),
(124, 'Liberia'),
(125, 'Libyan Arab Jamahiriya'),
(126, 'Liechtenstein'),
(127, 'Lithuania'),
(128, 'Luxembourg'),
(129, 'Macau'),
(130, 'Macedonia'),
(131, 'Madagascar'),
(132, 'Malawi'),
(133, 'Malaysia'),
(134, 'Maldives'),
(135, 'Mali'),
(136, 'Malta'),
(137, 'Marshall Islands'),
(138, 'Martinique'),
(139, 'Mauritania'),
(140, 'Mauritius'),
(141, 'Mayotte'),
(142, 'Mexico'),
(143, 'Micronesia, Federated States of'),
(144, 'Moldova, Republic of'),
(145, 'Monaco'),
(146, 'Mongolia'),
(147, 'Montenegro'),
(148, 'Montserrat'),
(149, 'Morocco'),
(150, 'Mozambique'),
(151, 'Myanmar'),
(152, 'Namibia'),
(153, 'Nauru'),
(154, 'Nepal'),
(155, 'Netherlands'),
(156, 'Netherlands Antilles'),
(157, 'New Caledonia'),
(158, 'New Zealand'),
(159, 'Nicaragua'),
(160, 'Niger'),
(161, 'Nigeria'),
(162, 'Niue'),
(163, 'Norfolk Island'),
(164, 'Northern Mariana Islands'),
(165, 'Norway'),
(166, 'Oman'),
(167, 'Pakistan'),
(168, 'Palau'),
(169, 'Palestine'),
(170, 'Panama'),
(171, 'Papua New Guinea'),
(172, 'Paraguay'),
(173, 'Peru'),
(174, 'Philippines'),
(175, 'Pitcairn'),
(176, 'Poland'),
(177, 'Portugal'),
(178, 'Puerto Rico'),
(179, 'Qatar'),
(180, 'Reunion'),
(181, 'Romania'),
(182, 'Russian Federation'),
(183, 'Rwanda'),
(184, 'Saint Kitts and Nevis'),
(185, 'Saint Lucia'),
(186, 'Saint Vincent and the Grenadines'),
(187, 'Samoa'),
(188, 'San Marino'),
(189, 'Sao Tome and Principe'),
(190, 'Saudi Arabia'),
(191, 'Senegal'),
(192, 'Serbia'),
(193, 'Seychelles'),
(194, 'Sierra Leone'),
(195, 'Singapore'),
(196, 'Slovakia'),
(197, 'Slovenia'),
(198, 'Solomon Islands'),
(199, 'Somalia'),
(200, 'South Africa'),
(201, 'South Georgia South Sandwich Islands'),
(202, 'Spain'),
(203, 'Sri Lanka'),
(204, 'St. Helena'),
(205, 'St. Pierre and Miquelon'),
(206, 'Sudan'),
(207, 'Suriname'),
(208, 'Svalbard and Jan Mayen Islands'),
(209, 'Swaziland'),
(210, 'Sweden'),
(211, 'Switzerland'),
(212, 'Syrian Arab Republic'),
(213, 'Taiwan'),
(214, 'Tajikistan'),
(215, 'Tanzania, United Republic of'),
(216, 'Thailand'),
(217, 'Togo'),
(218, 'Tokelau'),
(219, 'Tonga'),
(220, 'Trinidad and Tobago'),
(221, 'Tunisia'),
(222, 'Turkey'),
(223, 'Turkmenistan'),
(224, 'Turks and Caicos Islands'),
(225, 'Tuvalu'),
(226, 'Uganda'),
(227, 'Ukraine'),
(228, 'United Arab Emirates'),
(229, 'United Kingdom'),
(230, 'United States'),
(231, 'United States minor outlying islands'),
(232, 'Uruguay'),
(233, 'Uzbekistan'),
(234, 'Vanuatu'),
(235, 'Vatican City State'),
(236, 'Venezuela'),
(237, 'Vietnam'),
(238, 'Virgin Islands (British)'),
(239, 'Virgin Islands (U.S.)'),
(240, 'Wallis and Futuna Islands'),
(241, 'Western Sahara'),
(242, 'Yemen'),
(243, 'Zaire'),
(244, 'Zambia'),
(245, 'Zimbabwe');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_customer`
--

CREATE TABLE `tbl_customer` (
  `cust_id` int(11) NOT NULL,
  `cust_name` varchar(100) NOT NULL,
  `cust_cname` varchar(100) NOT NULL,
  `cust_email` varchar(100) NOT NULL,
  `cust_phone` varchar(50) NOT NULL,
  `cust_country` int(11) NOT NULL,
  `cust_address` text NOT NULL,
  `cust_city` varchar(100) NOT NULL,
  `cust_state` varchar(100) NOT NULL,
  `cust_zip` varchar(30) NOT NULL,
  `cust_b_name` varchar(100) NOT NULL,
  `cust_b_cname` varchar(100) NOT NULL,
  `cust_b_phone` varchar(50) NOT NULL,
  `cust_b_country` int(11) NOT NULL,
  `cust_b_address` text NOT NULL,
  `cust_b_city` varchar(100) NOT NULL,
  `cust_b_state` varchar(100) NOT NULL,
  `cust_b_zip` varchar(30) NOT NULL,
  `cust_s_name` varchar(100) NOT NULL,
  `cust_s_cname` varchar(100) NOT NULL,
  `cust_s_phone` varchar(50) NOT NULL,
  `cust_s_country` int(11) NOT NULL,
  `cust_s_address` text NOT NULL,
  `cust_s_city` varchar(100) NOT NULL,
  `cust_s_state` varchar(100) NOT NULL,
  `cust_s_zip` varchar(30) NOT NULL,
  `cust_password` varchar(100) NOT NULL,
  `cust_token` varchar(191) NOT NULL,
  `cust_datetime` varchar(100) NOT NULL,
  `cust_timestamp` varchar(100) NOT NULL,
  `cust_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Volcado de datos para la tabla `tbl_customer`
--

INSERT INTO `tbl_customer` (`cust_id`, `cust_name`, `cust_cname`, `cust_email`, `cust_phone`, `cust_country`, `cust_address`, `cust_city`, `cust_state`, `cust_zip`, `cust_b_name`, `cust_b_cname`, `cust_b_phone`, `cust_b_country`, `cust_b_address`, `cust_b_city`, `cust_b_state`, `cust_b_zip`, `cust_s_name`, `cust_s_cname`, `cust_s_phone`, `cust_s_country`, `cust_s_address`, `cust_s_city`, `cust_s_state`, `cust_s_zip`, `cust_password`, `cust_token`, `cust_datetime`, `cust_timestamp`, `cust_status`) VALUES
(18, 'Jose', 'Beiker Company', 'hjosealfredo55@gmail.com', '79506673', 63, 'vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv', 'Lourdes', 'Colon', '1154', 'Jose Alfredo Hernandez Soriano', 'Beiker S.A de C.V.', '79506673', 63, 'hhh', 'Colon', 'La Libertad', '15014', 'Jose Alfredo Hernandez Soriano', 'Beiker S.A de C.V.', '79506673', 63, 'hhh', 'Colon', 'La lIbertad', '15014', 'cb1c487f23ae18eeb08cf78dacbb311e', 'db335cf4589af37bbfef50d060ac2525', '2025-10-27 18:58:21', '1761616701', 1),
(21, 'Jose Hernandez', 'Beiker Company', 'hjosealfredo2012@gmail.com', '79506673', 63, 'Km 25, Residencial Bosques de Lourdes, Poligono 36, casa 22', 'La Libertad', 'La Libertad', 'hjosealfredo2012@gmail.com', '', '', '', 0, '', '', '', '', '', '', '', 0, '', '', '', '', 'cb1c487f23ae18eeb08cf78dacbb311e', '6965692d0579f10447dfa5e39779d3d9', '2025-11-28 20:58:54', '1764392334', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_customer_message`
--

CREATE TABLE `tbl_customer_message` (
  `customer_message_id` int(11) NOT NULL,
  `subject` varchar(191) NOT NULL,
  `message` text NOT NULL,
  `order_detail` text NOT NULL,
  `cust_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_end_category`
--

CREATE TABLE `tbl_end_category` (
  `ecat_id` int(11) NOT NULL,
  `ecat_name` varchar(191) NOT NULL,
  `mcat_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Volcado de datos para la tabla `tbl_end_category`
--

INSERT INTO `tbl_end_category` (`ecat_id`, `ecat_name`, `mcat_id`) VALUES
(88, 'MSI', 21),
(89, 'ASUS', 21),
(90, 'DELL', 22),
(92, 'HP', 22),
(93, 'ACER', 22),
(94, 'Ultra / Enthusiast Build', 23),
(95, 'High-End Gaming PC', 23),
(96, 'Mid-Range Gaming PC', 23),
(97, 'Entry-Level Gaming PC', 23),
(98, 'Office Desktop PC', 24),
(99, 'All-in-One PC', 24),
(100, 'Mini Office PC', 24),
(106, 'CORE i3', 27),
(107, 'CORE i5', 27),
(108, 'CORE i7', 27),
(109, 'CORE i9', 27),
(110, 'Ryzen 3', 28),
(111, 'Ryzen 5', 28),
(112, 'Ryzen 7', 28),
(113, 'Ryzen 9', 28),
(114, 'GeForce RTX 50 series', 8),
(115, 'GeForce RTX 40 series', 8),
(116, 'GeForce RTX 30 series', 8),
(117, 'GeForce RTX 20 series', 8),
(118, 'GeForce GTX 10 series', 8),
(119, 'GeForce GTX 16 series', 8),
(120, 'Serie Radeon RX 9000', 18),
(121, 'Serie Radeon RX 7000', 18),
(122, 'Serie Radeon RX 6000', 18),
(123, 'Serie Radeon RX 5000', 18);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_faq`
--

CREATE TABLE `tbl_faq` (
  `faq_id` int(11) NOT NULL,
  `faq_title` varchar(191) NOT NULL,
  `faq_content` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Volcado de datos para la tabla `tbl_faq`
--

INSERT INTO `tbl_faq` (`faq_id`, `faq_title`, `faq_content`) VALUES
(1, 'How to find an item?', '<h3 class=\"checkout-complete-box font-bold txt16\" style=\"box-sizing: inherit; text-rendering: optimizeLegibility; margin: 0.2rem 0px 0.5rem; padding: 0px; line-height: 1.4; background-color: rgb(250, 250, 250);\"><font color=\"#222222\" face=\"opensans, Helvetica Neue, Helvetica, Helvetica, Arial, sans-serif\"><span style=\"font-size: 15.7143px;\">We have a wide range of fabulous products to choose from.</span></font></h3><h3 class=\"checkout-complete-box font-bold txt16\" style=\"box-sizing: inherit; text-rendering: optimizeLegibility; margin: 0.2rem 0px 0.5rem; padding: 0px; line-height: 1.4; background-color: rgb(250, 250, 250);\"><span style=\"font-size: 15.7143px; color: rgb(34, 34, 34); font-family: opensans, \"Helvetica Neue\", Helvetica, Helvetica, Arial, sans-serif;\">Tip 1: If you\'re looking for a specific product, use the keyword search box located at the top of the site. Simply type what you are looking for, and prepare to be amazed!</span></h3><h3 class=\"checkout-complete-box font-bold txt16\" style=\"box-sizing: inherit; text-rendering: optimizeLegibility; margin: 0.2rem 0px 0.5rem; padding: 0px; line-height: 1.4; background-color: rgb(250, 250, 250);\"><font color=\"#222222\" face=\"opensans, Helvetica Neue, Helvetica, Helvetica, Arial, sans-serif\"><span style=\"font-size: 15.7143px;\">Tip 2: If you want to explore a category of products, use the Shop Categories in the upper menu, and navigate through your favorite categories where we\'ll feature the best products in each.</span></font><br><br></h3>\r\n'),
(2, 'What is your return policy?', '<p><span style=\"color: rgb(10, 10, 10); font-family: opensans, &quot;Helvetica Neue&quot;, Helvetica, Helvetica, Arial, sans-serif; font-size: 14px; text-align: center;\">You have 15 days to make a refund request after your order has been delivered.</span><br></p>\r\n'),
(3, ' I received a defective/damaged item, can I get a refund?', '<p>In case the item you received is damaged or defective, you could return an item in the same condition as you received it with the original box and/or packaging intact. Once we receive the returned item, we will inspect it and if the item is found to be defective or damaged, we will process the refund along with any shipping fees incurred.<br></p>\r\n'),
(4, 'When are ‘Returns’ not possible?', '<h2 data-start=\"133\" data-end=\"159\"><strong data-start=\"136\" data-end=\"159\">Return Restrictions</strong></h2><p data-start=\"161\" data-end=\"222\">There are certain situations where we cannot accept a return:</p><p class=\"a  \" style=\"box-sizing: inherit; text-rendering: optimizeLegibility; line-height: 1.6; margin-bottom: 0.714286rem; padding: 0px; font-size: 14px; color: rgb(10, 10, 10); font-family: opensans, \" helvetica=\"\" neue\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" background-color:=\"\" rgb(250,=\"\" 250,=\"\" 250);\"=\"\">\r\n\r\n</p><ul data-start=\"224\" data-end=\"855\">\r\n<li data-start=\"224\" data-end=\"287\">\r\n<p data-start=\"226\" data-end=\"287\">The return request is made <strong data-start=\"253\" data-end=\"270\">after 15 days</strong> from delivery.</p>\r\n</li>\r\n<li data-start=\"288\" data-end=\"379\">\r\n<p data-start=\"290\" data-end=\"379\">The product has been <strong data-start=\"311\" data-end=\"339\">used, installed, damaged</strong>, or is not in the original condition.</p>\r\n</li>\r\n<li data-start=\"380\" data-end=\"503\">\r\n<p data-start=\"382\" data-end=\"503\"><strong data-start=\"382\" data-end=\"405\">Computer components</strong> (CPU, GPU, motherboard, RAM, SSD/HDD, PSU, coolers, etc.) showing signs of installation or use.</p>\r\n</li>\r\n<li data-start=\"504\" data-end=\"611\">\r\n<p data-start=\"506\" data-end=\"611\">Items that are <strong data-start=\"521\" data-end=\"566\">covered under the manufacturer’s warranty</strong> (must be handled directly with the brand).</p>\r\n</li>\r\n<li data-start=\"612\" data-end=\"669\">\r\n<p data-start=\"614\" data-end=\"669\">Products with <strong data-start=\"628\" data-end=\"666\">tampered or missing serial numbers</strong>.</p>\r\n</li>\r\n<li data-start=\"670\" data-end=\"789\">\r\n<p data-start=\"672\" data-end=\"789\">Missing items from the original package, including <strong data-start=\"723\" data-end=\"786\">labels, accessories, cables, manuals, or original packaging</strong>.</p>\r\n</li>\r\n<li data-start=\"790\" data-end=\"855\">\r\n<p data-start=\"792\" data-end=\"855\"><strong data-start=\"792\" data-end=\"812\">Fragile hardware</strong> or items damaged due to improper handling.</p></li></ul>\r\n'),
(5, 'What are the items that cannot be returned?', '<h2 data-start=\"123\" data-end=\"150\"><strong data-start=\"126\" data-end=\"150\">Non-Returnable Items</strong></h2><p data-start=\"152\" data-end=\"220\">The following items <strong data-start=\"172\" data-end=\"219\">cannot be returned once opened or installed</strong>:</p><ul data-start=\"222\" data-end=\"472\">\r\n<li data-start=\"222\" data-end=\"247\">\r\n<p data-start=\"224\" data-end=\"247\"><strong data-start=\"224\" data-end=\"245\">Processors (CPUs)</strong></p>\r\n</li>\r\n<li data-start=\"248\" data-end=\"277\">\r\n<p data-start=\"250\" data-end=\"277\"><strong data-start=\"250\" data-end=\"275\">Graphics Cards (GPUs)</strong></p>\r\n</li>\r\n<li data-start=\"278\" data-end=\"298\">\r\n<p data-start=\"280\" data-end=\"298\"><strong data-start=\"280\" data-end=\"296\">Motherboards</strong></p>\r\n</li>\r\n<li data-start=\"299\" data-end=\"319\">\r\n<p data-start=\"301\" data-end=\"319\"><strong data-start=\"301\" data-end=\"317\">Memory (RAM)</strong></p>\r\n</li>\r\n<li data-start=\"320\" data-end=\"359\">\r\n<p data-start=\"322\" data-end=\"359\"><strong data-start=\"322\" data-end=\"357\">Storage Drives (SSD, HDD, NVMe)</strong></p>\r\n</li>\r\n<li data-start=\"360\" data-end=\"388\">\r\n<p data-start=\"362\" data-end=\"388\"><strong data-start=\"362\" data-end=\"386\">Power Supplies (PSU)</strong></p>\r\n</li>\r\n<li data-start=\"389\" data-end=\"412\">\r\n<p data-start=\"391\" data-end=\"412\"><strong data-start=\"391\" data-end=\"410\">Cooling Systems</strong></p>\r\n</li>\r\n<li data-start=\"413\" data-end=\"472\">\r\n<p data-start=\"415\" data-end=\"472\"><strong data-start=\"415\" data-end=\"472\">Any PC component showing signs of installation or use</strong></p>\r\n</li>\r\n</ul><h3 data-start=\"474\" data-end=\"497\"><strong data-start=\"478\" data-end=\"497\">Clearance Items</strong></h3><ul data-start=\"498\" data-end=\"546\">\r\n<li data-start=\"498\" data-end=\"546\">\r\n<p data-start=\"500\" data-end=\"546\">Products marked as <em data-start=\"519\" data-end=\"531\">Final Sale</em> or <em data-start=\"535\" data-end=\"546\">No-Return</em></p>\r\n</li>\r\n</ul><p>\r\n\r\n\r\n\r\n\r\n</p><p data-start=\"548\" data-end=\"647\">Any hardware that is damaged, modified, or shows installation marks is <strong data-start=\"619\" data-end=\"646\">not eligible for return</strong>.</p>');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_language`
--

CREATE TABLE `tbl_language` (
  `lang_id` int(11) NOT NULL,
  `lang_name` varchar(191) NOT NULL,
  `lang_value` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Volcado de datos para la tabla `tbl_language`
--

INSERT INTO `tbl_language` (`lang_id`, `lang_name`, `lang_value`) VALUES
(1, 'Currency', '$'),
(2, 'Search Product', 'Search Product'),
(3, 'Search', 'Search'),
(4, 'Submit', 'Submit'),
(5, 'Update', 'Update'),
(6, 'Read More', 'Read More'),
(7, 'Serial', 'Serial'),
(8, 'Photo', 'Photo'),
(9, 'Login', 'Login'),
(10, 'Customer Login', 'Customer Login'),
(11, 'Click here to login', 'Click here to login'),
(12, 'Back to Login Page', 'Back to Login Page'),
(13, 'Logged in as', 'Logged in as'),
(14, 'Logout', 'Logout'),
(15, 'Register', 'Register'),
(16, 'Customer Registration', 'Customer Registration'),
(17, 'Registration Successful', 'Registration Successful'),
(18, 'Cart', 'Cart'),
(19, 'View Cart', 'View Cart'),
(20, 'Update Cart', 'Update Cart'),
(21, 'Back to Cart', 'Back to Cart'),
(22, 'Checkout', 'Checkout'),
(23, 'Proceed to Checkout', 'Proceed to Checkout'),
(24, 'Orders', 'Orders'),
(25, 'Order History', 'Order History'),
(26, 'Order Details', 'Order Details'),
(27, 'Payment Date and Time', 'Payment Date and Time'),
(28, 'Transaction ID', 'Transaction ID'),
(29, 'Paid Amount', 'Paid Amount'),
(30, 'Payment Status', 'Payment Status'),
(31, 'Payment Method', 'Payment Method'),
(32, 'Payment ID', 'Payment ID'),
(33, 'Payment Section', 'Payment Section'),
(34, 'Select Payment Method', 'Select Payment Method'),
(35, 'Select a Method', 'Select a Method'),
(36, 'PayPal', 'PayPal'),
(37, 'Stripe', 'Stripe'),
(38, 'Bank Deposit', 'Bank Deposit'),
(39, 'Card Number', 'Card Number'),
(40, 'CVV', 'CVV'),
(41, 'Month', 'Month'),
(42, 'Year', 'Year'),
(43, 'Send to this Details', 'Send to this Details'),
(44, 'Transaction Information', 'Transaction Information'),
(45, 'Include transaction id and other information correctly', 'Include transaction id and other information correctly'),
(46, 'Pay Now', 'Pay Now'),
(47, 'Product Name', 'Product Name'),
(48, 'Product Details', 'Product Details'),
(49, 'Categories', 'Categories'),
(50, 'Category:', 'Category:'),
(51, 'All Products Under', 'All Products Under'),
(52, 'Select Size', 'Select Size'),
(53, 'Select Color', 'Select Color'),
(54, 'Product Price', 'Product Price'),
(55, 'Quantity', 'Quantity'),
(56, 'Out of Stock', 'Out of Stock'),
(57, 'Share This', 'Share This'),
(58, 'Share This Product', 'Share This Product'),
(59, 'Product Description', 'Product Description'),
(60, 'Features', 'Features'),
(61, 'Conditions', 'Conditions'),
(62, 'Return Policy', 'Return Policy'),
(63, 'Reviews', 'Reviews'),
(64, 'Review', 'Review'),
(65, 'Give a Review', 'Give a Review'),
(66, 'Write your comment (Optional)', 'Write your comment (Optional)'),
(67, 'Submit Review', 'Submit Review'),
(68, 'You already have given a rating!', 'You already have given a rating!'),
(69, 'You must have to login to give a review', 'You must have to login to give a review'),
(70, 'No description found', 'No description found'),
(71, 'No feature found', 'No feature found'),
(72, 'No condition found', 'No condition found'),
(73, 'No return policy found', 'No return policy found'),
(74, 'Review not found', 'Review not found'),
(75, 'Customer Name', 'Customer Name'),
(76, 'Comment', 'Comment'),
(77, 'Comments', 'Comments'),
(78, 'Rating', 'Rating'),
(79, 'Previous', 'Previous'),
(80, 'Next', 'Next'),
(81, 'Sub Total', 'Sub Total'),
(82, 'Total', 'Total'),
(83, 'Action', 'Action'),
(84, 'Shipping Cost', 'Shipping Cost'),
(85, 'Continue Shopping', 'Continue Shopping'),
(86, 'Update Billing Address', 'Update Billing Address'),
(87, 'Update Shipping Address', 'Update Shipping Address'),
(88, 'Update Billing and Shipping Info', 'Update Billing and Shipping Info'),
(89, 'Dashboard', 'Dashboard'),
(90, 'Welcome to the Dashboard', 'Welcome to the Dashboard'),
(91, 'Back to Dashboard', 'Back to Dashboard'),
(92, 'Subscribe', 'Subscribe'),
(93, 'Subscribe To Our Newsletter', 'Subscribe To Our Newsletter'),
(94, 'Email Address', 'Email Address'),
(95, 'Enter Your Email Address', 'Enter Your Email Address'),
(96, 'Password', 'Password'),
(97, 'Forget Password', 'Forget Password'),
(98, 'Retype Password', 'Retype Password'),
(99, 'Update Password', 'Update Password'),
(100, 'New Password', 'New Password'),
(101, 'Retype New Password', 'Retype New Password'),
(102, 'Full Name', 'Full Name'),
(103, 'Company Name', 'Company Name'),
(104, 'Phone Number', 'Phone Number'),
(105, 'Address', 'Address'),
(106, 'Country', 'Country'),
(107, 'City', 'City'),
(108, 'State', 'State'),
(109, 'Zip Code', 'Zip Code'),
(110, 'About Us', 'About Us'),
(111, 'Featured Posts', 'Featured Posts'),
(112, 'Popular Posts', 'Popular Posts'),
(113, 'Recent Posts', 'Recent Posts'),
(114, 'Contact Information', 'Contact Information'),
(115, 'Contact Form', 'Contact Form'),
(116, 'Our Office', 'Our Office'),
(117, 'Update Profile', 'Update Profile'),
(118, 'Send Message', 'Send Message'),
(119, 'Message', 'Message'),
(120, 'Find Us On Map', 'Find Us On Map'),
(121, 'Congratulation! Payment is successful.', 'Congratulation! Payment is successful.'),
(122, 'Billing and Shipping Information is updated successfully.', 'Billing and Shipping Information is updated successfully.'),
(123, 'Customer Name can not be empty.', 'Customer Name can not be empty.'),
(124, 'Phone Number can not be empty.', 'Phone Number can not be empty.'),
(125, 'Address can not be empty.', 'Address can not be empty.'),
(126, 'You must have to select a country.', 'You must have to select a country.'),
(127, 'City can not be empty.', 'City can not be empty.'),
(128, 'State can not be empty.', 'State can not be empty.'),
(129, 'Zip Code can not be empty.', 'Zip Code can not be empty.'),
(130, 'Profile Information is updated successfully.', 'Profile Information is updated successfully.'),
(131, 'Email Address can not be empty', 'Email Address can not be empty'),
(132, 'Email and/or Password can not be empty.', 'Email and/or Password can not be empty.'),
(133, 'Email Address does not match.', 'Email Address does not match.'),
(134, 'Email address must be valid.', 'Email address must be valid.'),
(135, 'You email address is not found in our system.', 'You email address is not found in our system.'),
(136, 'Please check your email and confirm your subscription.', 'Please check your email and confirm your subscription.'),
(137, 'Your email is verified successfully. You can now login to our website.', 'Your email is verified successfully. You can now login to our website.'),
(138, 'Password can not be empty.', 'Password can not be empty.'),
(139, 'Passwords do not match.', 'Passwords do not match.'),
(140, 'Please enter new and retype passwords.', 'Please enter new and retype passwords.'),
(141, 'Password is updated successfully.', 'Password is updated successfully.'),
(142, 'To reset your password, please click on the link below.', 'To reset your password, please click on the link below.'),
(143, 'PASSWORD RESET REQUEST - YOUR WEBSITE.COM', 'PASSWORD RESET REQUEST - YOUR WEBSITE.COM'),
(144, 'The password reset email time (24 hours) has expired. Please again try to reset your password.', 'The password reset email time (24 hours) has expired. Please again try to reset your password.'),
(145, 'A confirmation link is sent to your email address. You will get the password reset information in there.', 'A confirmation link is sent to your email address. You will get the password reset information in there.'),
(146, 'Password is reset successfully. You can now login.', 'Password is reset successfully. You can now login.'),
(147, 'Email Address Already Exists', 'Email Address Already Exists.'),
(148, 'Sorry! Your account is inactive. Please contact to the administrator.', 'Sorry! Your account is inactive. Please contact to the administrator.'),
(149, 'Change Password', 'Change Password'),
(150, 'Registration Email Confirmation for YOUR WEBSITE', 'Registration Email Confirmation for YOUR WEBSITE.'),
(151, 'Thank you for your registration! Your account has been created. To active your account click on the link below:', 'Thank you for your registration! Your account has been created. To active your account click on the link below:'),
(152, 'Your registration is completed. Please check your email address to follow the process to confirm your registration.', 'Your registration is completed. Please check your email address to follow the process to confirm your registration.'),
(153, 'No Product Found', 'No Product Found'),
(154, 'Add to Cart', 'Add to Cart'),
(155, 'Related Products', 'Related Products'),
(156, 'See all related products from below', 'See all the related products from below'),
(157, 'Size', 'Size'),
(158, 'Color', 'Color'),
(159, 'Price', 'Price'),
(160, 'Please login as customer to checkout', 'Please login as customer to checkout'),
(161, 'Billing Address', 'Billing Address'),
(162, 'Shipping Address', 'Shipping Address'),
(163, 'Rating is Submitted Successfully!', 'Rating is Submitted Successfully!');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_mid_category`
--

CREATE TABLE `tbl_mid_category` (
  `mcat_id` int(11) NOT NULL,
  `mcat_name` varchar(191) NOT NULL,
  `tcat_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Volcado de datos para la tabla `tbl_mid_category`
--

INSERT INTO `tbl_mid_category` (`mcat_id`, `mcat_name`, `tcat_id`) VALUES
(8, 'NVIDIA', 1),
(18, 'AMD', 1),
(21, 'Gaming', 2),
(22, 'Business/school', 2),
(23, 'Gaming', 3),
(24, 'Business/school', 3),
(27, 'INTEL', 6),
(28, 'AMD', 6);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_order`
--

CREATE TABLE `tbl_order` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(191) NOT NULL,
  `size` varchar(100) NOT NULL,
  `color` varchar(100) NOT NULL,
  `quantity` varchar(50) NOT NULL,
  `unit_price` varchar(50) NOT NULL,
  `payment_id` varchar(191) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Volcado de datos para la tabla `tbl_order`
--

INSERT INTO `tbl_order` (`id`, `product_id`, `product_name`, `size`, `color`, `quantity`, `unit_price`, `payment_id`) VALUES
(10, 106, 'Intel® Core™ i3 14100 Processor', '', '', '1', '230', '1764398410'),
(11, 118, 'PNY NVIDIA GeForce RTX™ 5070 Epic-X™ ARGB OC Triple Fan', '', '', '1', '579.99', '1764398467'),
(12, 106, 'Intel® Core™ i3 14100 Processor', '', '', '3', '230', '1764399108'),
(13, 118, 'PNY NVIDIA GeForce RTX™ 5070 Epic-X™ ARGB OC Triple Fan', '', '', '1', '579.99', '1764399160');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_page`
--

CREATE TABLE `tbl_page` (
  `id` int(11) NOT NULL,
  `about_title` varchar(191) NOT NULL,
  `about_content` text NOT NULL,
  `about_banner` varchar(191) NOT NULL,
  `about_meta_title` varchar(191) NOT NULL,
  `about_meta_keyword` text NOT NULL,
  `about_meta_description` text NOT NULL,
  `faq_title` varchar(191) NOT NULL,
  `faq_banner` varchar(191) NOT NULL,
  `faq_meta_title` varchar(191) NOT NULL,
  `faq_meta_keyword` text NOT NULL,
  `faq_meta_description` text NOT NULL,
  `blog_title` varchar(191) NOT NULL,
  `blog_banner` varchar(191) NOT NULL,
  `blog_meta_title` varchar(191) NOT NULL,
  `blog_meta_keyword` text NOT NULL,
  `blog_meta_description` text NOT NULL,
  `contact_title` varchar(191) NOT NULL,
  `contact_banner` varchar(191) NOT NULL,
  `contact_meta_title` varchar(191) NOT NULL,
  `contact_meta_keyword` text NOT NULL,
  `contact_meta_description` text NOT NULL,
  `pgallery_title` varchar(191) NOT NULL,
  `pgallery_banner` varchar(191) NOT NULL,
  `pgallery_meta_title` varchar(191) NOT NULL,
  `pgallery_meta_keyword` text NOT NULL,
  `pgallery_meta_description` text NOT NULL,
  `vgallery_title` varchar(191) NOT NULL,
  `vgallery_banner` varchar(191) NOT NULL,
  `vgallery_meta_title` varchar(191) NOT NULL,
  `vgallery_meta_keyword` text NOT NULL,
  `vgallery_meta_description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Volcado de datos para la tabla `tbl_page`
--

INSERT INTO `tbl_page` (`id`, `about_title`, `about_content`, `about_banner`, `about_meta_title`, `about_meta_keyword`, `about_meta_description`, `faq_title`, `faq_banner`, `faq_meta_title`, `faq_meta_keyword`, `faq_meta_description`, `blog_title`, `blog_banner`, `blog_meta_title`, `blog_meta_keyword`, `blog_meta_description`, `contact_title`, `contact_banner`, `contact_meta_title`, `contact_meta_keyword`, `contact_meta_description`, `pgallery_title`, `pgallery_banner`, `pgallery_meta_title`, `pgallery_meta_keyword`, `pgallery_meta_description`, `vgallery_title`, `vgallery_banner`, `vgallery_meta_title`, `vgallery_meta_keyword`, `vgallery_meta_description`) VALUES
(1, 'About Us', '<h1 data-start=\"98\" data-end=\"159\"><strong data-start=\"100\" data-end=\"159\">Welcome to Digital World – Your PC Hardware Destination</strong></h1><p data-start=\"161\" data-end=\"366\">At Digital World, we provide high-quality computer parts, accessories, and tech gear at competitive prices. Our goal is simple: offer reliable products, fast service, and customer support you can count on.</p><p data-start=\"368\" data-end=\"501\">We stay up-to-date with the latest trends in hardware, gaming, and technology to bring you the best options for any build or upgrade.</p><hr data-start=\"503\" data-end=\"506\"><h2 data-start=\"508\" data-end=\"540\"><strong data-start=\"511\" data-end=\"540\">Why Choose Digital World?</strong></h2><ul data-start=\"542\" data-end=\"707\">\r\n<li data-start=\"542\" data-end=\"580\">\r\n<p data-start=\"544\" data-end=\"580\"><strong data-start=\"544\" data-end=\"564\">Quality Products</strong> you can trust</p>\r\n</li>\r\n<li data-start=\"581\" data-end=\"621\">\r\n<p data-start=\"583\" data-end=\"621\"><strong data-start=\"583\" data-end=\"605\">Competitive Prices</strong> on top brands</p>\r\n</li>\r\n<li data-start=\"622\" data-end=\"651\">\r\n<p data-start=\"624\" data-end=\"651\"><strong data-start=\"624\" data-end=\"649\">24/7 Customer Support</strong></p>\r\n</li>\r\n<li data-start=\"652\" data-end=\"682\">\r\n<p data-start=\"654\" data-end=\"682\"><strong data-start=\"654\" data-end=\"680\">Fast &amp; Secure Shipping</strong></p>\r\n</li>\r\n<li data-start=\"683\" data-end=\"707\">\r\n<p data-start=\"685\" data-end=\"707\"><strong data-start=\"685\" data-end=\"707\">Easy 3-Day Returns</strong></p>\r\n</li>\r\n</ul><hr data-start=\"709\" data-end=\"712\"><h2 data-start=\"714\" data-end=\"744\"><strong data-start=\"717\" data-end=\"744\">Your Trusted Tech Store</strong></h2><p data-start=\"746\" data-end=\"894\">Whether you’re building a new PC, upgrading your setup, or looking for the right accessory, our team is here to help you find exactly what you need.</p><p data-start=\"896\" data-end=\"933\"><strong data-start=\"896\" data-end=\"933\">Digital World — Tech made simple.</strong></p><hr data-start=\"935\" data-end=\"938\"><p data-start=\"218\" data-end=\"297\">\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n</p><p data-start=\"940\" data-end=\"1025\" data-is-last-node=\"\" data-is-only-node=\"\"><br></p>\r\n', 'about-banner.jpg', 'Digital World - About Us', 'about, about us, about computers, about company.', 'Our goal has always been to get the best in computers and component\'s', 'FAQ', 'faq-banner.jpg', 'Digital World - FAQ', '', '', 'Blog', 'blog-banner.jpg', 'Ecommerce - Blog', '', '', 'Contact Us', 'contact-banner.jpg', 'Digital World - Contact', '', '', 'Photo Gallery', 'pgallery-banner.jpg', 'Ecommerce - Photo Gallery', '', '', 'Video Gallery', 'vgallery-banner.jpg', 'Ecommerce - Video Gallery', '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_payment`
--

CREATE TABLE `tbl_payment` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(191) NOT NULL,
  `customer_email` varchar(191) NOT NULL,
  `payment_date` varchar(50) NOT NULL,
  `txnid` varchar(191) NOT NULL,
  `paid_amount` int(11) NOT NULL,
  `card_number` varchar(50) NOT NULL,
  `card_cvv` varchar(10) NOT NULL,
  `card_month` varchar(10) NOT NULL,
  `card_year` varchar(10) NOT NULL,
  `bank_transaction_info` text NOT NULL,
  `payment_method` varchar(20) NOT NULL,
  `payment_status` varchar(25) NOT NULL,
  `shipping_status` varchar(20) NOT NULL,
  `payment_id` varchar(191) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Volcado de datos para la tabla `tbl_payment`
--

INSERT INTO `tbl_payment` (`id`, `customer_id`, `customer_name`, `customer_email`, `payment_date`, `txnid`, `paid_amount`, `card_number`, `card_cvv`, `card_month`, `card_year`, `bank_transaction_info`, `payment_method`, `payment_status`, `shipping_status`, `payment_id`) VALUES
(61, 18, 'Jose', 'hjosealfredo55@gmail.com', '2025-11-28 22:40:10', '', 230, '', '', '', '', '44', 'Bank Deposit', 'Completed', 'Pending', '1764398410'),
(62, 18, 'Jose', 'hjosealfredo55@gmail.com', '2025-11-28 22:41:07', '', 580, '', '', '', '', '', 'PayPal', 'Completed', 'Pending', '1764398467'),
(63, 18, 'Jose', 'hjosealfredo55@gmail.com', '2025-11-28 22:51:48', '', 690, '', '', '', '', '444', 'Bank Deposit', 'Completed', 'Pending', '1764399108'),
(64, 18, 'Jose', 'hjosealfredo55@gmail.com', '2025-11-28 22:52:40', '', 580, '', '', '', '', '', 'PayPal', 'Pending', 'Pending', '1764399160');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_photo`
--

CREATE TABLE `tbl_photo` (
  `id` int(11) NOT NULL,
  `caption` varchar(191) NOT NULL,
  `photo` varchar(191) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Volcado de datos para la tabla `tbl_photo`
--

INSERT INTO `tbl_photo` (`id`, `caption`, `photo`) VALUES
(1, 'Photo 1', 'photo-1.jpg'),
(2, 'Photo 2', 'photo-2.jpg'),
(3, 'Photo 3', 'photo-3.jpg'),
(4, 'Photo 4', 'photo-4.jpg'),
(5, 'Photo 5', 'photo-5.jpg'),
(6, 'Photo 6', 'photo-6.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_post`
--

CREATE TABLE `tbl_post` (
  `post_id` int(11) NOT NULL,
  `post_title` varchar(191) NOT NULL,
  `post_slug` varchar(191) NOT NULL,
  `post_content` text NOT NULL,
  `post_date` varchar(191) NOT NULL,
  `photo` varchar(191) NOT NULL,
  `category_id` int(11) NOT NULL,
  `total_view` int(11) NOT NULL,
  `meta_title` varchar(191) NOT NULL,
  `meta_keyword` text NOT NULL,
  `meta_description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Volcado de datos para la tabla `tbl_post`
--

INSERT INTO `tbl_post` (`post_id`, `post_title`, `post_slug`, `post_content`, `post_date`, `photo`, `category_id`, `total_view`, `meta_title`, `meta_keyword`, `meta_description`) VALUES
(1, 'Cu vel choro exerci pri et oratio iisque', 'cu-vel-choro-exerci-pri-et-oratio-iisque', '<p>Lorem ipsum dolor sit amet, qui case probo velit no, an postea scaevola partiendo mei. Id mea fuisset perpetua referrentur. Ut everti ceteros mei, alii discere eum no, duo id malis iuvaret. Ad sint everti accusam vel, ea viderer suscipiantur pri. Brute option minimum in cum, ignota iuvaret an pro.</p>\r\n\r\n<p>Solum atqui intellegebat mea an. Ne ius alterum aliquam. Ea nec populo aliquid mentitum, vis in meliore atomorum, sanctus consequat vituperatoribus duo ea. Ad doctus pertinacia ius, virtute fuisset id has, eum ut modo principes. Qui eu labore adversarium, oporteat delicata qui ut, an qui meliore principes. Id aliquid dolorum nam.</p>\r\n\r\n<p>Reque pericula philosophia ut mei, volumus eligendi mandamus has an. In nobis consulatu pri, has at timeam scaevola, has simul quaeque et. Te nec sale accumsan. Dolorem prodesset efficiendi sea ea.</p>\r\n\r\n<p>Et habeo modus debitis pri, vel quis fierent albucius ne. Ea animal meliore usu, nec etiam dolorum atomorum at, nam in audire mandamus omittantur. Cu ius dicam officiis molestiae, mea volumus officiis cotidieque no. Ut vel possim interpretaris, idque probatus antiopam has ad. Facilisi qualisque te sea, no dolorum mnesarchum usu.</p>\r\n\r\n<p>Eum tota graeci impetus an, eirmod invenire rationibus ne mel. Ignota habemus eum ex, vis omnesque delicata perpetua an. Sit id modo invidunt sapientem, ne eum vocibus dolores phaedrum. Case praesent appellantur eu per.</p>\r\n', '05-09-2017', 'news-1.jpg', 3, 14, 'Cu vel choro exerci pri et oratio iisque', '', ''),
(2, 'Epicurei necessitatibus eu facilisi postulant ', 'epicurei-necessitatibus-eu-facilisi-postulant-', '<p>Lorem ipsum dolor sit amet, qui case probo velit no, an postea scaevola partiendo mei. Id mea fuisset perpetua referrentur. Ut everti ceteros mei, alii discere eum no, duo id malis iuvaret. Ad sint everti accusam vel, ea viderer suscipiantur pri. Brute option minimum in cum, ignota iuvaret an pro.</p>\r\n\r\n<p>Solum atqui intellegebat mea an. Ne ius alterum aliquam. Ea nec populo aliquid mentitum, vis in meliore atomorum, sanctus consequat vituperatoribus duo ea. Ad doctus pertinacia ius, virtute fuisset id has, eum ut modo principes. Qui eu labore adversarium, oporteat delicata qui ut, an qui meliore principes. Id aliquid dolorum nam.</p>\r\n\r\n<p>Reque pericula philosophia ut mei, volumus eligendi mandamus has an. In nobis consulatu pri, has at timeam scaevola, has simul quaeque et. Te nec sale accumsan. Dolorem prodesset efficiendi sea ea.</p>\r\n\r\n<p>Et habeo modus debitis pri, vel quis fierent albucius ne. Ea animal meliore usu, nec etiam dolorum atomorum at, nam in audire mandamus omittantur. Cu ius dicam officiis molestiae, mea volumus officiis cotidieque no. Ut vel possim interpretaris, idque probatus antiopam has ad. Facilisi qualisque te sea, no dolorum mnesarchum usu.</p>\r\n\r\n<p>Eum tota graeci impetus an, eirmod invenire rationibus ne mel. Ignota habemus eum ex, vis omnesque delicata perpetua an. Sit id modo invidunt sapientem, ne eum vocibus dolores phaedrum. Case praesent appellantur eu per.</p>\r\n', '05-09-2017', 'news-2.jpg', 3, 6, 'Epicurei necessitatibus eu facilisi postulant ', '', ''),
(3, 'Mei ut errem legimus periculis eos liber', 'mei-ut-errem-legimus-periculis-eos-liber', '<p>Lorem ipsum dolor sit amet, qui case probo velit no, an postea scaevola partiendo mei. Id mea fuisset perpetua referrentur. Ut everti ceteros mei, alii discere eum no, duo id malis iuvaret. Ad sint everti accusam vel, ea viderer suscipiantur pri. Brute option minimum in cum, ignota iuvaret an pro.</p>\r\n\r\n<p>Solum atqui intellegebat mea an. Ne ius alterum aliquam. Ea nec populo aliquid mentitum, vis in meliore atomorum, sanctus consequat vituperatoribus duo ea. Ad doctus pertinacia ius, virtute fuisset id has, eum ut modo principes. Qui eu labore adversarium, oporteat delicata qui ut, an qui meliore principes. Id aliquid dolorum nam.</p>\r\n\r\n<p>Reque pericula philosophia ut mei, volumus eligendi mandamus has an. In nobis consulatu pri, has at timeam scaevola, has simul quaeque et. Te nec sale accumsan. Dolorem prodesset efficiendi sea ea.</p>\r\n\r\n<p>Et habeo modus debitis pri, vel quis fierent albucius ne. Ea animal meliore usu, nec etiam dolorum atomorum at, nam in audire mandamus omittantur. Cu ius dicam officiis molestiae, mea volumus officiis cotidieque no. Ut vel possim interpretaris, idque probatus antiopam has ad. Facilisi qualisque te sea, no dolorum mnesarchum usu.</p>\r\n\r\n<p>Eum tota graeci impetus an, eirmod invenire rationibus ne mel. Ignota habemus eum ex, vis omnesque delicata perpetua an. Sit id modo invidunt sapientem, ne eum vocibus dolores phaedrum. Case praesent appellantur eu per.</p>\r\n', '05-09-2017', 'news-3.jpg', 3, 1, 'Mei ut errem legimus periculis eos liber', '', ''),
(4, 'Id pro unum pertinax oportere vel', 'id-pro-unum-pertinax-oportere-vel', '<p>Lorem ipsum dolor sit amet, qui case probo velit no, an postea scaevola partiendo mei. Id mea fuisset perpetua referrentur. Ut everti ceteros mei, alii discere eum no, duo id malis iuvaret. Ad sint everti accusam vel, ea viderer suscipiantur pri. Brute option minimum in cum, ignota iuvaret an pro.</p>\r\n\r\n<p>Solum atqui intellegebat mea an. Ne ius alterum aliquam. Ea nec populo aliquid mentitum, vis in meliore atomorum, sanctus consequat vituperatoribus duo ea. Ad doctus pertinacia ius, virtute fuisset id has, eum ut modo principes. Qui eu labore adversarium, oporteat delicata qui ut, an qui meliore principes. Id aliquid dolorum nam.</p>\r\n\r\n<p>Reque pericula philosophia ut mei, volumus eligendi mandamus has an. In nobis consulatu pri, has at timeam scaevola, has simul quaeque et. Te nec sale accumsan. Dolorem prodesset efficiendi sea ea.</p>\r\n\r\n<p>Et habeo modus debitis pri, vel quis fierent albucius ne. Ea animal meliore usu, nec etiam dolorum atomorum at, nam in audire mandamus omittantur. Cu ius dicam officiis molestiae, mea volumus officiis cotidieque no. Ut vel possim interpretaris, idque probatus antiopam has ad. Facilisi qualisque te sea, no dolorum mnesarchum usu.</p>\r\n\r\n<p>Eum tota graeci impetus an, eirmod invenire rationibus ne mel. Ignota habemus eum ex, vis omnesque delicata perpetua an. Sit id modo invidunt sapientem, ne eum vocibus dolores phaedrum. Case praesent appellantur eu per.</p>\r\n', '05-09-2017', 'news-4.jpg', 4, 0, 'Id pro unum pertinax oportere vel', '', ''),
(5, 'Tollit cetero cu usu etiam evertitur', 'tollit-cetero-cu-usu-etiam-evertitur', '<p>Lorem ipsum dolor sit amet, qui case probo velit no, an postea scaevola partiendo mei. Id mea fuisset perpetua referrentur. Ut everti ceteros mei, alii discere eum no, duo id malis iuvaret. Ad sint everti accusam vel, ea viderer suscipiantur pri. Brute option minimum in cum, ignota iuvaret an pro.</p>\r\n\r\n<p>Solum atqui intellegebat mea an. Ne ius alterum aliquam. Ea nec populo aliquid mentitum, vis in meliore atomorum, sanctus consequat vituperatoribus duo ea. Ad doctus pertinacia ius, virtute fuisset id has, eum ut modo principes. Qui eu labore adversarium, oporteat delicata qui ut, an qui meliore principes. Id aliquid dolorum nam.</p>\r\n\r\n<p>Reque pericula philosophia ut mei, volumus eligendi mandamus has an. In nobis consulatu pri, has at timeam scaevola, has simul quaeque et. Te nec sale accumsan. Dolorem prodesset efficiendi sea ea.</p>\r\n\r\n<p>Et habeo modus debitis pri, vel quis fierent albucius ne. Ea animal meliore usu, nec etiam dolorum atomorum at, nam in audire mandamus omittantur. Cu ius dicam officiis molestiae, mea volumus officiis cotidieque no. Ut vel possim interpretaris, idque probatus antiopam has ad. Facilisi qualisque te sea, no dolorum mnesarchum usu.</p>\r\n\r\n<p>Eum tota graeci impetus an, eirmod invenire rationibus ne mel. Ignota habemus eum ex, vis omnesque delicata perpetua an. Sit id modo invidunt sapientem, ne eum vocibus dolores phaedrum. Case praesent appellantur eu per.</p>\r\n', '05-09-2017', 'news-5.jpg', 4, 24, 'Tollit cetero cu usu etiam evertitur', '', ''),
(6, 'Omnes ornatus qui et te aeterno', 'omnes-ornatus-qui-et-te-aeterno', '<p>Lorem ipsum dolor sit amet, qui case probo velit no, an postea scaevola partiendo mei. Id mea fuisset perpetua referrentur. Ut everti ceteros mei, alii discere eum no, duo id malis iuvaret. Ad sint everti accusam vel, ea viderer suscipiantur pri. Brute option minimum in cum, ignota iuvaret an pro.</p>\r\n\r\n<p>Solum atqui intellegebat mea an. Ne ius alterum aliquam. Ea nec populo aliquid mentitum, vis in meliore atomorum, sanctus consequat vituperatoribus duo ea. Ad doctus pertinacia ius, virtute fuisset id has, eum ut modo principes. Qui eu labore adversarium, oporteat delicata qui ut, an qui meliore principes. Id aliquid dolorum nam.</p>\r\n\r\n<p>Reque pericula philosophia ut mei, volumus eligendi mandamus has an. In nobis consulatu pri, has at timeam scaevola, has simul quaeque et. Te nec sale accumsan. Dolorem prodesset efficiendi sea ea.</p>\r\n\r\n<p>Et habeo modus debitis pri, vel quis fierent albucius ne. Ea animal meliore usu, nec etiam dolorum atomorum at, nam in audire mandamus omittantur. Cu ius dicam officiis molestiae, mea volumus officiis cotidieque no. Ut vel possim interpretaris, idque probatus antiopam has ad. Facilisi qualisque te sea, no dolorum mnesarchum usu.</p>\r\n\r\n<p>Eum tota graeci impetus an, eirmod invenire rationibus ne mel. Ignota habemus eum ex, vis omnesque delicata perpetua an. Sit id modo invidunt sapientem, ne eum vocibus dolores phaedrum. Case praesent appellantur eu per.</p>\r\n', '05-09-2017', 'news-6.jpg', 4, 2, 'Omnes ornatus qui et te aeterno', '', ''),
(7, 'Vix tale noluisse voluptua ad ne', 'vix-tale-noluisse-voluptua-ad-ne', '<p>Lorem ipsum dolor sit amet, qui case probo velit no, an postea scaevola partiendo mei. Id mea fuisset perpetua referrentur. Ut everti ceteros mei, alii discere eum no, duo id malis iuvaret. Ad sint everti accusam vel, ea viderer suscipiantur pri. Brute option minimum in cum, ignota iuvaret an pro.</p>\r\n\r\n<p>Solum atqui intellegebat mea an. Ne ius alterum aliquam. Ea nec populo aliquid mentitum, vis in meliore atomorum, sanctus consequat vituperatoribus duo ea. Ad doctus pertinacia ius, virtute fuisset id has, eum ut modo principes. Qui eu labore adversarium, oporteat delicata qui ut, an qui meliore principes. Id aliquid dolorum nam.</p>\r\n\r\n<p>Reque pericula philosophia ut mei, volumus eligendi mandamus has an. In nobis consulatu pri, has at timeam scaevola, has simul quaeque et. Te nec sale accumsan. Dolorem prodesset efficiendi sea ea.</p>\r\n\r\n<p>Et habeo modus debitis pri, vel quis fierent albucius ne. Ea animal meliore usu, nec etiam dolorum atomorum at, nam in audire mandamus omittantur. Cu ius dicam officiis molestiae, mea volumus officiis cotidieque no. Ut vel possim interpretaris, idque probatus antiopam has ad. Facilisi qualisque te sea, no dolorum mnesarchum usu.</p>\r\n\r\n<p>Eum tota graeci impetus an, eirmod invenire rationibus ne mel. Ignota habemus eum ex, vis omnesque delicata perpetua an. Sit id modo invidunt sapientem, ne eum vocibus dolores phaedrum. Case praesent appellantur eu per.</p>\r\n', '05-09-2017', 'news-7.jpg', 2, 0, 'Vix tale noluisse voluptua ad ne', '', ''),
(8, 'Liber utroque vim an ne his brute', 'liber-utroque-vim-an-ne-his-brute', '<p>Lorem ipsum dolor sit amet, qui case probo velit no, an postea scaevola partiendo mei. Id mea fuisset perpetua referrentur. Ut everti ceteros mei, alii discere eum no, duo id malis iuvaret. Ad sint everti accusam vel, ea viderer suscipiantur pri. Brute option minimum in cum, ignota iuvaret an pro.</p>\r\n\r\n<p>Solum atqui intellegebat mea an. Ne ius alterum aliquam. Ea nec populo aliquid mentitum, vis in meliore atomorum, sanctus consequat vituperatoribus duo ea. Ad doctus pertinacia ius, virtute fuisset id has, eum ut modo principes. Qui eu labore adversarium, oporteat delicata qui ut, an qui meliore principes. Id aliquid dolorum nam.</p>\r\n\r\n<p>Reque pericula philosophia ut mei, volumus eligendi mandamus has an. In nobis consulatu pri, has at timeam scaevola, has simul quaeque et. Te nec sale accumsan. Dolorem prodesset efficiendi sea ea.</p>\r\n\r\n<p>Et habeo modus debitis pri, vel quis fierent albucius ne. Ea animal meliore usu, nec etiam dolorum atomorum at, nam in audire mandamus omittantur. Cu ius dicam officiis molestiae, mea volumus officiis cotidieque no. Ut vel possim interpretaris, idque probatus antiopam has ad. Facilisi qualisque te sea, no dolorum mnesarchum usu.</p>\r\n\r\n<p>Eum tota graeci impetus an, eirmod invenire rationibus ne mel. Ignota habemus eum ex, vis omnesque delicata perpetua an. Sit id modo invidunt sapientem, ne eum vocibus dolores phaedrum. Case praesent appellantur eu per.</p>\r\n', '05-09-2017', 'news-8.jpg', 2, 12, 'Liber utroque vim an ne his brute', '', ''),
(9, 'Nostrum copiosae argumentum has', 'nostrum-copiosae-argumentum-has', '<p>Lorem ipsum dolor sit amet, qui case probo velit no, an postea scaevola partiendo mei. Id mea fuisset perpetua referrentur. Ut everti ceteros mei, alii discere eum no, duo id malis iuvaret. Ad sint everti accusam vel, ea viderer suscipiantur pri. Brute option minimum in cum, ignota iuvaret an pro.</p>\r\n\r\n<p>Solum atqui intellegebat mea an. Ne ius alterum aliquam. Ea nec populo aliquid mentitum, vis in meliore atomorum, sanctus consequat vituperatoribus duo ea. Ad doctus pertinacia ius, virtute fuisset id has, eum ut modo principes. Qui eu labore adversarium, oporteat delicata qui ut, an qui meliore principes. Id aliquid dolorum nam.</p>\r\n\r\n<p>Reque pericula philosophia ut mei, volumus eligendi mandamus has an. In nobis consulatu pri, has at timeam scaevola, has simul quaeque et. Te nec sale accumsan. Dolorem prodesset efficiendi sea ea.</p>\r\n\r\n<p>Et habeo modus debitis pri, vel quis fierent albucius ne. Ea animal meliore usu, nec etiam dolorum atomorum at, nam in audire mandamus omittantur. Cu ius dicam officiis molestiae, mea volumus officiis cotidieque no. Ut vel possim interpretaris, idque probatus antiopam has ad. Facilisi qualisque te sea, no dolorum mnesarchum usu.</p>\r\n\r\n<p>Eum tota graeci impetus an, eirmod invenire rationibus ne mel. Ignota habemus eum ex, vis omnesque delicata perpetua an. Sit id modo invidunt sapientem, ne eum vocibus dolores phaedrum. Case praesent appellantur eu per.</p>\r\n', '05-09-2017', 'news-9.jpg', 1, 12, 'Nostrum copiosae argumentum has', '', ''),
(10, 'An labores explicari qui eu', 'an-labores-explicari-qui-eu', '<p>Lorem ipsum dolor sit amet, qui case probo velit no, an postea scaevola partiendo mei. Id mea fuisset perpetua referrentur. Ut everti ceteros mei, alii discere eum no, duo id malis iuvaret. Ad sint everti accusam vel, ea viderer suscipiantur pri. Brute option minimum in cum, ignota iuvaret an pro.</p>\r\n\r\n<p>Solum atqui intellegebat mea an. Ne ius alterum aliquam. Ea nec populo aliquid mentitum, vis in meliore atomorum, sanctus consequat vituperatoribus duo ea. Ad doctus pertinacia ius, virtute fuisset id has, eum ut modo principes. Qui eu labore adversarium, oporteat delicata qui ut, an qui meliore principes. Id aliquid dolorum nam.</p>\r\n\r\n<p>Reque pericula philosophia ut mei, volumus eligendi mandamus has an. In nobis consulatu pri, has at timeam scaevola, has simul quaeque et. Te nec sale accumsan. Dolorem prodesset efficiendi sea ea.</p>\r\n\r\n<p>Et habeo modus debitis pri, vel quis fierent albucius ne. Ea animal meliore usu, nec etiam dolorum atomorum at, nam in audire mandamus omittantur. Cu ius dicam officiis molestiae, mea volumus officiis cotidieque no. Ut vel possim interpretaris, idque probatus antiopam has ad. Facilisi qualisque te sea, no dolorum mnesarchum usu.</p>\r\n\r\n<p>Eum tota graeci impetus an, eirmod invenire rationibus ne mel. Ignota habemus eum ex, vis omnesque delicata perpetua an. Sit id modo invidunt sapientem, ne eum vocibus dolores phaedrum. Case praesent appellantur eu per.</p>\r\n', '05-09-2017', 'news-10.jpg', 1, 4, 'An labores explicari qui eu', '', ''),
(11, 'Lorem ipsum dolor sit amet', 'lorem-ipsum-dolor-sit-amet', '<p>Lorem ipsum dolor sit amet, qui case probo velit no, an postea scaevola partiendo mei. Id mea fuisset perpetua referrentur. Ut everti ceteros mei, alii discere eum no, duo id malis iuvaret. Ad sint everti accusam vel, ea viderer suscipiantur pri. Brute option minimum in cum, ignota iuvaret an pro.</p>\r\n\r\n<p>Solum atqui intellegebat mea an. Ne ius alterum aliquam. Ea nec populo aliquid mentitum, vis in meliore atomorum, sanctus consequat vituperatoribus duo ea. Ad doctus pertinacia ius, virtute fuisset id has, eum ut modo principes. Qui eu labore adversarium, oporteat delicata qui ut, an qui meliore principes. Id aliquid dolorum nam.</p>\r\n\r\n<p>Reque pericula philosophia ut mei, volumus eligendi mandamus has an. In nobis consulatu pri, has at timeam scaevola, has simul quaeque et. Te nec sale accumsan. Dolorem prodesset efficiendi sea ea.</p>\r\n\r\n<p>Et habeo modus debitis pri, vel quis fierent albucius ne. Ea animal meliore usu, nec etiam dolorum atomorum at, nam in audire mandamus omittantur. Cu ius dicam officiis molestiae, mea volumus officiis cotidieque no. Ut vel possim interpretaris, idque probatus antiopam has ad. Facilisi qualisque te sea, no dolorum mnesarchum usu.</p>\r\n\r\n<p>Eum tota graeci impetus an, eirmod invenire rationibus ne mel. Ignota habemus eum ex, vis omnesque delicata perpetua an. Sit id modo invidunt sapientem, ne eum vocibus dolores phaedrum. Case praesent appellantur eu per.</p>\r\n', '05-09-2017', 'news-11.jpg', 1, 18, 'Lorem ipsum dolor sit amet', '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_product`
--

CREATE TABLE `tbl_product` (
  `p_id` int(11) NOT NULL,
  `p_name` varchar(191) NOT NULL,
  `p_old_price` varchar(10) DEFAULT NULL,
  `p_current_price` varchar(10) DEFAULT NULL,
  `p_qty` int(10) DEFAULT 0,
  `p_featured_photo` varchar(191) DEFAULT NULL,
  `p_description` text NOT NULL,
  `p_short_description` text NOT NULL,
  `p_feature` text NOT NULL,
  `p_condition` text NOT NULL,
  `p_return_policy` text NOT NULL,
  `p_total_view` int(11) DEFAULT 0,
  `p_is_featured` int(1) DEFAULT 0,
  `p_is_active` int(1) DEFAULT 1,
  `ecat_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Volcado de datos para la tabla `tbl_product`
--

INSERT INTO `tbl_product` (`p_id`, `p_name`, `p_old_price`, `p_current_price`, `p_qty`, `p_featured_photo`, `p_description`, `p_short_description`, `p_feature`, `p_condition`, `p_return_policy`, `p_total_view`, `p_is_featured`, `p_is_active`, `ecat_id`) VALUES
(106, 'Intel® Core™ i3 14100 Processor', '250', '230', 1, 'product-featured-106.jpg', '<p>Intel Core i3-14100 Desktop Processor (14th Generation). With PCIe 5.0 and 4.0 support, and DDR5 and DDR4 support, the Intel Core i3 (14th Generation) desktop processors are optimized for productivity. Compatible with motherboards based on Intel 700 Series and Intel 600 Series chipsets. 60W base processor power. Intel Laminar RM1 included in the box.</p>', '<ul><li>Style: Computer Processor</li><li>Brand: Intel</li><li>CPU Manufacturer: Intel</li><li>CPU Model: Core i3</li><li>CPU Speed: 4.7 GHz</li><li>CPU Socket: PGA LGA1700</li></ul>', '<ul><li>4 cores (4 P cores + 0 E cores) and 8 threads. Includes integrated Intel UHD Graphics 730.</li><li>Dual-core microarchitecture performance, prioritizing and distributing workloads to optimize performance.</li><li>Up to 4.7 GHz unlocked. 12 MB cache.</li><li>Compatible with Intel 600 series (with possible BIOS update) and 700 series chipset-based motherboards.</li><li>Supports PCIe 5.0 and 4.0. Compatible with DDR4 and DDR5 memory. RM1 thermal solution included.</li><li>Includes Intel RM1 Laminar Cooler.</li></ul>', '', '<p>You can return any new computer purchased from Amazon.com that arrives damaged or defective, or is still in an unopened box, for a full refund within 30 days of purchase.</p>', 10, 1, 1, 106),
(107, 'Intel® Core™ i3-12100F Processor', '', '82.49', 10, 'product-featured-107.jpg', '<ul class=\"a-unordered-list a-vertical a-spacing-mini\" style=\"margin-right: 0px; margin-bottom: 0px; margin-left: 18px; color: rgb(15, 17, 17); padding: 0px; font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px;\"><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Intel Core i3-12100F Desktop Processor 4 (4P-0E) Cores Up to 4.3 GHz Turbo Frequency LGA1700 600 Series Chipset 58W Processor Base Power</span></li></ul>', '<div id=\"twister_feature_div\" class=\"celwidget\" data-feature-name=\"twister\" data-csa-c-type=\"widget\" data-csa-c-content-id=\"twister\" data-csa-c-slot-id=\"twister_feature_div\" data-csa-c-asin=\"B09NPJX7PV\" data-csa-c-is-in-initial-active-row=\"false\" data-csa-c-id=\"crub45-kdzy4i-kkul3w-joxkzv\" data-cel-widget=\"twister_feature_div\" style=\"\"><div id=\"twister-plus-desktop-twister-container\" data-csa-c-content-id=\"twister-plus-inline-twister-container\" data-csa-c-slot-id=\"twister-plus-inline-twister-container\" data-csa-c-type=\"slot\" class=\"a-cardui-deck inline-twister-container-margins\" name=\"a-cardui-deck-autoname-0\" data-csa-c-id=\"rqnkfb-w5ntq6-zfie5c-357a43\" style=\"background-color: transparent; padding-top: 0.1px; padding-bottom: 0.1px; margin: 0px;\"><div id=\"twister-plus-inline-twister-card\" class=\"a-cardui inline-twister-card-padding\" data-a-card-type=\"basic\" name=\"a-cardui-deck-autoname-0-card0\" style=\"margin: 0px; overflow: visible; padding: 0px;\"><div class=\"a-cardui-body\" style=\"padding: 0px; position: relative;\"><div id=\"twister-plus-inline-twister\" class=\"a-section\" style=\"margin-bottom: 0px;\"><div id=\"inline-twister-singleton-header-style_name\" class=\"a-section a-spacing-none inline-twister-singleton-header\" style=\"margin-bottom: 0px; padding: 4px 0px;\"><font color=\"#0f1111\" face=\"Amazon Ember, Arial, sans-serif\"><span style=\"font-size: 14px;\">Intel® Core™ 12th Gen i3-12100F desktop processor, featuring PCIe Gen 5.0 & 4.0 support, DDR5 and DDR4 support. Discrete graphics required.</span></font></div></div></div></div></div></div>', '<div id=\"twister_feature_div\" class=\"celwidget\" data-feature-name=\"twister\" data-csa-c-type=\"widget\" data-csa-c-content-id=\"twister\" data-csa-c-slot-id=\"twister_feature_div\" data-csa-c-asin=\"B09NPJX7PV\" data-csa-c-is-in-initial-active-row=\"false\" data-csa-c-id=\"crub45-kdzy4i-kkul3w-joxkzv\" data-cel-widget=\"twister_feature_div\" style=\"color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px;\"><div id=\"twister-plus-desktop-twister-container\" data-csa-c-content-id=\"twister-plus-inline-twister-container\" data-csa-c-slot-id=\"twister-plus-inline-twister-container\" data-csa-c-type=\"slot\" class=\"a-cardui-deck inline-twister-container-margins\" name=\"a-cardui-deck-autoname-0\" data-csa-c-id=\"rqnkfb-w5ntq6-zfie5c-357a43\" style=\"background-color: transparent; padding-top: 0.1px; padding-bottom: 0.1px; margin: 0px;\"><div id=\"twister-plus-inline-twister-card\" class=\"a-cardui inline-twister-card-padding\" data-a-card-type=\"basic\" name=\"a-cardui-deck-autoname-0-card0\" style=\"margin: 0px; overflow: visible; padding: 0px;\"><div class=\"a-cardui-body\" style=\"padding: 0px; position: relative;\"><div id=\"twister-plus-inline-twister\" class=\"a-section\" style=\"margin-bottom: 0px;\"><div id=\"inline-twister-singleton-header-style_name\" class=\"a-section a-spacing-none inline-twister-singleton-header\" style=\"margin-bottom: 0px; padding: 4px 0px;\"><span class=\"a-size-base a-color-secondary inline-twister-dim-title\" style=\"line-height: 20px !important; color: rgb(86, 89, 89) !important;\">Style: </span><span id=\"inline-twister-expanded-dimension-text-style_name\" class=\"a-size-base inline-twister-dim-title-value-truncate a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Processor</span></div></div></div></div></div></div><div id=\"bundles_feature_div\" class=\"celwidget\" data-feature-name=\"bundles\" data-csa-c-type=\"widget\" data-csa-c-content-id=\"bundles\" data-csa-c-slot-id=\"bundles_feature_div\" data-csa-c-asin=\"B09NPJX7PV\" data-csa-c-is-in-initial-active-row=\"false\" data-csa-c-id=\"uxsqpm-cjobnd-dn8wdl-o19xud\" data-cel-widget=\"bundles_feature_div\" style=\"color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px;\"></div><div id=\"valueAdds_feature_div\" class=\"celwidget\" data-feature-name=\"valueAdds\" data-csa-c-type=\"widget\" data-csa-c-content-id=\"valueAdds\" data-csa-c-slot-id=\"valueAdds_feature_div\" data-csa-c-asin=\"B09NPJX7PV\" data-csa-c-is-in-initial-active-row=\"false\" data-csa-c-id=\"s94e7w-fm11my-ib32qa-onke1\" data-cel-widget=\"valueAdds_feature_div\" style=\"color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px;\"></div><div id=\"clickToContact_feature_div\" class=\"celwidget\" data-feature-name=\"clickToContact\" data-csa-c-type=\"widget\" data-csa-c-content-id=\"clickToContact\" data-csa-c-slot-id=\"clickToContact_feature_div\" data-csa-c-asin=\"B09NPJX7PV\" data-csa-c-is-in-initial-active-row=\"false\" data-csa-c-id=\"xxtsvp-637kkb-bsj59z-h7ozr0\" data-cel-widget=\"clickToContact_feature_div\" style=\"color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px;\"></div><div id=\"dpreviewBadge_feature_div\" class=\"celwidget\" data-feature-name=\"dpreviewBadge\" data-csa-c-type=\"widget\" data-csa-c-content-id=\"dpreviewBadge\" data-csa-c-slot-id=\"dpreviewBadge_feature_div\" data-csa-c-asin=\"B09NPJX7PV\" data-csa-c-is-in-initial-active-row=\"false\" data-csa-c-id=\"y19mw5-pz6ggd-pgayva-pgfe0s\" data-cel-widget=\"dpreviewBadge_feature_div\" style=\"color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px;\"></div><div id=\"amazonCertifiedBadge_feature_div\" class=\"celwidget\" data-feature-name=\"amazonCertifiedBadge\" data-csa-c-type=\"widget\" data-csa-c-content-id=\"amazonCertifiedBadge\" data-csa-c-slot-id=\"amazonCertifiedBadge_feature_div\" data-csa-c-asin=\"B09NPJX7PV\" data-csa-c-is-in-initial-active-row=\"false\" data-csa-c-id=\"7790i6-qd1um4-d26pxv-iyc9lk\" data-cel-widget=\"amazonCertifiedBadge_feature_div\" style=\"color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px;\"></div><div id=\"smartHomeWidget_feature_div\" class=\"celwidget\" data-feature-name=\"smartHomeWidget\" data-csa-c-type=\"widget\" data-csa-c-content-id=\"smartHomeWidget\" data-csa-c-slot-id=\"smartHomeWidget_feature_div\" data-csa-c-asin=\"B09NPJX7PV\" data-csa-c-is-in-initial-active-row=\"false\" data-csa-c-id=\"idamy6-8n1n1-uibnhf-42ipfe\" data-cel-widget=\"smartHomeWidget_feature_div\" style=\"color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px;\"></div><div id=\"renewedProgramDescriptionAtf_feature_div\" class=\"celwidget\" data-feature-name=\"renewedProgramDescriptionAtf\" data-csa-c-type=\"widget\" data-csa-c-content-id=\"renewedProgramDescriptionAtf\" data-csa-c-slot-id=\"renewedProgramDescriptionAtf_feature_div\" data-csa-c-asin=\"B09NPJX7PV\" data-csa-c-is-in-initial-active-row=\"false\" data-csa-c-id=\"c82940-ln9yag-ca12lf-xe3ktx\" data-cel-widget=\"renewedProgramDescriptionAtf_feature_div\" style=\"color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px;\"></div><div id=\"twisterPlusWWDesktop\" class=\"celwidget\" data-feature-name=\"twisterPlusWWDesktop\" data-csa-c-type=\"widget\" data-csa-c-content-id=\"twisterPlusWWDesktop\" data-csa-c-slot-id=\"twisterPlusWWDesktop\" data-csa-c-asin=\"B09NPJX7PV\" data-csa-c-is-in-initial-active-row=\"false\" data-csa-c-id=\"8j1w18-2985i7-r18jqp-hbdyuo\" data-cel-widget=\"twisterPlusWWDesktop\" style=\"color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px;\"><span class=\"a-declarative\" data-action=\"close-side-sheet\" data-close-side-sheet=\"{}\"></span></div><div id=\"unifiedTradeInTwisterPlusCardIngress_feature_div\" class=\"celwidget\" data-feature-name=\"unifiedTradeInTwisterPlusCardIngress\" data-csa-c-type=\"widget\" data-csa-c-content-id=\"unifiedTradeInTwisterPlusCardIngress\" data-csa-c-slot-id=\"unifiedTradeInTwisterPlusCardIngress_feature_div\" data-csa-c-asin=\"B09NPJX7PV\" data-csa-c-is-in-initial-active-row=\"false\" data-csa-c-id=\"4dg0bl-4ypmf5-h7v3r5-3r7r5w\" data-cel-widget=\"unifiedTradeInTwisterPlusCardIngress_feature_div\" style=\"color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px;\"><div class=\"celwidget c-f\" cel_widget_id=\"unified-trade-in_DetailPage_9\" data-csa-op-log-render=\"\" data-csa-c-content-id=\"DsUnknown\" data-csa-c-slot-id=\"DsUnknown-10\" data-csa-c-type=\"widget\" data-csa-c-painter=\"unified-trade-in-cards\" data-csa-c-id=\"sgxmc7-vgrmbw-vdu4el-nywuol\" data-cel-widget=\"unified-trade-in_DetailPage_9\"><div id=\"CardInstanceViv-I5GPcIEzEDfSM0IQyw\" data-card-metrics-id=\"unified-trade-in_DetailPage_9\" data-acp-tracking=\"{}\" data-mix-claimed=\"true\"><div></div></div></div></div><div id=\"gestaltCustomizationSummary_feature_div\" class=\"celwidget\" data-feature-name=\"gestaltCustomizationSummary\" data-csa-c-type=\"widget\" data-csa-c-content-id=\"gestaltCustomizationSummary\" data-csa-c-slot-id=\"gestaltCustomizationSummary_feature_div\" data-csa-c-asin=\"B09NPJX7PV\" data-csa-c-is-in-initial-active-row=\"false\" data-csa-c-id=\"i1g9wy-fnp2g3-pi18ze-c7r4o0\" data-cel-widget=\"gestaltCustomizationSummary_feature_div\" style=\"color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px;\"></div><div id=\"gestaltPredefinedCustomizations_feature_div\" class=\"celwidget\" data-feature-name=\"gestaltPredefinedCustomizations\" data-csa-c-type=\"widget\" data-csa-c-content-id=\"gestaltPredefinedCustomizations\" data-csa-c-slot-id=\"gestaltPredefinedCustomizations_feature_div\" data-csa-c-asin=\"B09NPJX7PV\" data-csa-c-is-in-initial-active-row=\"false\" data-csa-c-id=\"bssmv0-rj5ctw-7cjae0-huq0dv\" data-cel-widget=\"gestaltPredefinedCustomizations_feature_div\" style=\"color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px;\"></div><div id=\"buyingOptionNostosInlineBadge_feature_div\" class=\"celwidget\" data-feature-name=\"buyingOptionNostosInlineBadge\" data-csa-c-type=\"widget\" data-csa-c-content-id=\"buyingOptionNostosInlineBadge\" data-csa-c-slot-id=\"buyingOptionNostosInlineBadge_feature_div\" data-csa-c-asin=\"B09NPJX7PV\" data-csa-c-is-in-initial-active-row=\"false\" data-csa-c-id=\"5sctpd-uv77nu-bj7xb0-gy4stz\" data-cel-widget=\"buyingOptionNostosInlineBadge_feature_div\" style=\"color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px;\"></div><div id=\"productOverview_feature_div\" class=\"celwidget\" data-feature-name=\"productOverview\" data-csa-c-type=\"widget\" data-csa-c-content-id=\"productOverview\" data-csa-c-slot-id=\"productOverview_feature_div\" data-csa-c-asin=\"B09NPJX7PV\" data-csa-c-is-in-initial-active-row=\"false\" data-csa-c-id=\"u9waoe-8o5z6p-535t1d-o6gh8t\" data-cel-widget=\"productOverview_feature_div\" style=\"color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px;\"><div class=\"a-section a-spacing-small a-spacing-top-small\" style=\"margin-bottom: 0px; margin-top: 8px !important;\"><table class=\"a-normal a-spacing-micro\" role=\"list\" style=\"width: 666.969px; margin-bottom: 0px !important;\"><tbody><tr class=\"a-spacing-small po-brand\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Brand</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">Intel</span></td></tr><tr class=\"a-spacing-small po-cpu_model.manufacturer\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Manufacturer</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">Intel</span></td></tr><tr class=\"a-spacing-small po-cpu_model.family\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Model</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">Core i3-12100</span></td></tr><tr class=\"a-spacing-small po-cpu_model.speed\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Speed</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">2.5</span></td></tr><tr class=\"a-spacing-small po-cpu_model.socket\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-end: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Socket</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; padding-block-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">LGA 1700</span></td></tr></tbody></table></div></div>', '', '<p>You can return any new computer purchased from Amazon.com that arrives damaged or defective, or is still in an unopened box, for a full refund within 30 days of purchase.</p>', 1, 0, 1, 106),
(108, 'Intel® Core™ i9-14900K Processor', '', '438.97', 2, 'product-featured-108.jpg', '<p><span style=\"color: rgb(51, 51, 51); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: small;\">Intel® Core™ i9-14900K desktop processor. Featuring Intel Thermal Velocity Boost, Intel® Turbo Boost Max Technology 3.0 Frequency, PCIe 5.0 &amp; 4.0 support, DDR5 and DDR4 support, unlocked Intel® Core™ i9 desktop processors are optimized for enthusiast gamers and serious creators to help deliver high performance. Compatible with Intel® 700 Series and Intel® 600 Series (with potential BIOS update) chipset-based motherboards. 125W Processor Base Power.</span></p>', '<ul class=\"a-unordered-list a-vertical a-spacing-mini\" style=\"margin-right: 0px; margin-bottom: 0px; margin-left: 18px; color: rgb(15, 17, 17); padding: 0px; font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\"><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Game without compromise. Play harder and work smarter with Intel Core 14th Gen processors</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">24 cores (8 P-cores plus 16 E-cores) and 32 threads. Integrated Intel UHD Graphics 770 included</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Leading max clock speed of up to 6.0 GHz gives you smoother game play, higher frame rates, and rapid responsiveness</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Compatible with Intel 600-series (with potential BIOS update) or 700-series chipset-based motherboards</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">DDR4 and DDR5 platform support cuts your load times and gives you the space to run the most demanding games</span></li></ul>', '<table class=\"a-normal a-spacing-micro\" role=\"list\" style=\"width: 666.969px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px; background-color: rgb(255, 255, 255); margin-bottom: 0px !important;\"><tbody><tr class=\"a-spacing-small po-brand\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Brand</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">Intel</span></td></tr><tr class=\"a-spacing-small po-cpu_model.manufacturer\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Manufacturer</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">Intel</span></td></tr><tr class=\"a-spacing-small po-cpu_model.family\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Model</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">Core i9</span></td></tr><tr class=\"a-spacing-small po-cpu_model.speed\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Speed</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">6 GHz</span></td></tr><tr class=\"a-spacing-small po-cpu_model.socket\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-end: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Socket</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; padding-block-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">LGA 1700</span></td></tr></tbody></table>', '', '<div class=\"a-section table-padding\" style=\"margin-bottom: 22px; margin-left: 12px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\">DigitalWorld.com Return Policy:<span class=\"a-letter-space\" style=\"display: inline-block; width: 0.385em;\"></span>You may return any new computer purchased from DigitalWorld.com that is \"dead on arrival,\" arrives in damaged condition, or is still in unopened boxes, for a full refund within 30 days of purchase. DigitalWorld.com reserves the right to test \"dead on arrival\" returns and impose a customer fee equal to 15 percent of the product sales price if the customer misrepresents the condition of the product. Any returned computer that is damaged through customer misuse, is missing parts, or is in unsellable condition due to customer tampering will result in the customer being charged a higher restocking fee based on the condition of the product. Amazon.com will not accept returns of any desktop or notebook computer more than 30 days after you receive the shipment. New, used, and refurbished products purchased from Marketplace vendors are subject to the returns policy of the individual vendor.<table id=\"productDetails_warranty_support_sections\" class=\"a-keyvalue prodDetTable\" role=\"presentation\" style=\"margin-bottom: 22px; width: 704.594px; border-bottom: 1px solid rgb(213, 217, 217); table-layout: fixed; padding: 0px;\"></table></div><div class=\"a-section table-padding\" style=\"margin-bottom: 0px; margin-left: 12px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\">Manufacturer’s warranty can be requested from customer service.&nbsp;<a href=\"https://www.amazon.com/gp/help/customer/display.html/ref=help_search_1-1?nodeId=201596310\" target=\"_blank\" style=\"color: rgb(33, 98, 161); font-family: Arial;\">Click here</a>&nbsp;to make a request to customer service.</div>', 2, 0, 1, 109),
(109, 'Intel® Core™ Ultra 9 Processor', '618.43', '579', 1, 'product-featured-109.jpg', '<ul class=\"a-unordered-list a-vertical a-spacing-mini\" style=\"margin-right: 0px; margin-bottom: 0px; margin-left: 18px; color: rgb(15, 17, 17); padding: 0px; font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\"><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">24 cores (8 P-cores + 16 E-cores) and 24 threads. Integrated Intel Graphics included</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Performance hybrid architecture integrates two core microarchitectures, prioritizing and distributing workloads to optimize performance</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Up to 5.6 GHz. 40 MB Cache</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Compatible with Intel 800 series chipset-based motherboards</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Turbo Boost Max Technology 3.0, and PCIe 5.0 &amp; 4.0 support. Intel Optane Memory support. No thermal solution included</span></li></ul>', '<p>Intel® Core™ Ultra 9 Desktop Processor 285 24 cores (8 P-cores + 16 E-cores) up to 5.6 GHz</p>', '<p style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><table class=\"a-normal a-spacing-micro\" role=\"list\" style=\"width: 666.969px; background-color: rgb(255, 255, 255); margin-bottom: 0px !important;\"><tbody><tr class=\"a-spacing-small po-brand\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Brand</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">Intel</span></td></tr><tr class=\"a-spacing-small po-cpu_model.manufacturer\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Manufacturer</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">Intel</span></td></tr><tr class=\"a-spacing-small po-cpu_model.family\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Model</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">Intel Core Ultra 9</span></td></tr><tr class=\"a-spacing-small po-cpu_model.speed\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Speed</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">5.6 GHz</span></td></tr><tr class=\"a-spacing-small po-cpu_model.socket\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-end: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Socket</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; padding-block-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">FCLGA1851</span></td></tr></tbody></table></p>', '', '<div class=\"a-section table-padding\" style=\"margin-bottom: 22px; margin-left: 12px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\">DigitalWorld.com Return Policy:<span class=\"a-letter-space\" style=\"display: inline-block; width: 0.385em;\"></span>You may return any new computer purchased from DigitalWorld.com that is \"dead on arrival,\" arrives in damaged condition, or is still in unopened boxes, for a full refund within 30 days of purchase. DigitalWorld.com reserves the right to test \"dead on arrival\" returns and impose a customer fee equal to 15 percent of the product sales price if the customer misrepresents the condition of the product. Any returned computer that is damaged through customer misuse, is missing parts, or is in unsellable condition due to customer tampering will result in the customer being charged a higher restocking fee based on the condition of the product. Amazon.com will not accept returns of any desktop or notebook computer more than 30 days after you receive the shipment. New, used, and refurbished products purchased from Marketplace vendors are subject to the returns policy of the individual vendor.<table id=\"productDetails_warranty_support_sections\" class=\"a-keyvalue prodDetTable\" role=\"presentation\" style=\"margin-bottom: 22px; width: 704.594px; border-bottom: 1px solid rgb(213, 217, 217); table-layout: fixed; padding: 0px;\"></table></div><div class=\"a-section table-padding\" style=\"margin-bottom: 0px; margin-left: 12px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\">Manufacturer’s warranty can be requested from customer service.&nbsp;<a href=\"https://www.amazon.com/gp/help/customer/display.html/ref=help_search_1-1?nodeId=201596310\" target=\"_blank\" style=\"color: rgb(33, 98, 161); font-family: Arial;\">Click here</a>&nbsp;to make a request to customer service.</div>', 0, 1, 1, 109),
(110, 'Intel Core i7-13700K Processor', '', '310', 7, 'product-featured-110.jpg', '<ul class=\"a-unordered-list a-vertical a-spacing-mini\" style=\"margin-right: 0px; margin-bottom: 0px; margin-left: 18px; color: rgb(15, 17, 17); padding: 0px; font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\"><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">13th Gen Intel Core processors offer revolutionary design for beyond real-world performance. From extreme multitasking, immersive streaming, and faster creating, do what you do</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">16 cores (8 P-cores plus 8 E-cores) and 24 threads</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Up to 5.4 GHz unlocked. 30M Cache</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Integrated Intel UHD Graphics 770 included</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Compatible with Intel 600 series (might need BIOS update) and 700 series chipset-based motherboards</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Performance hybrid architecture integrates two core microarchitectures, prioritizing and distributing workloads to optimize performance</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Turbo Boost Max Technology 3.0, and PCIe 5.0 and 4.0 support. Intel Optane Memory support. No thermal solution included</span></li></ul>', '<p style=\"padding: 0px; margin-top: 0em; margin-bottom: 1em; margin-left: 1em; color: rgb(51, 51, 51); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: small;\">13th Gen Intel Core i7-13900K desktop processor. Featuring Intel Turbo Boost Max Technology 3.0, and PCIe 5.0 &amp; 4.0 support, DDR5 and DDR4 support, unlocked 13th Gen Intel Core i7 desktop processors are optimized for gamers and productivity and help deliver high performance. Compatible with Intel 700 Series and Intel 600 Series Chipset based motherboards. 125W Processor Base Power.</p><p style=\"padding: 0px; margin-top: 0em; margin-bottom: 1em; margin-left: 1em; color: rgb(51, 51, 51); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: small;\">Chipset Compatibility: Find compatible motherboards by accessing the Intel® Product Compatibility Tool, click Desktop and Workstation Processors , and choose the processor to find available compatible motherboards and other related information.&nbsp;</p>', '<table class=\"a-normal a-spacing-micro\" role=\"list\" style=\"width: 666.969px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px; background-color: rgb(255, 255, 255); margin-bottom: 0px !important;\"><tbody><tr class=\"a-spacing-small po-brand\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Brand</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">Intel</span></td></tr><tr class=\"a-spacing-small po-cpu_model.manufacturer\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Manufacturer</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">Intel</span></td></tr><tr class=\"a-spacing-small po-cpu_model.family\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Model</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">Core i7</span></td></tr><tr class=\"a-spacing-small po-cpu_model.speed\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Speed</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">5.4 GHz</span></td></tr><tr class=\"a-spacing-small po-cpu_model.socket\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-end: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Socket</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; padding-block-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">LGA 1700</span></td></tr></tbody></table>', '', '<div class=\"a-section table-padding\" style=\"margin-bottom: 22px; margin-left: 12px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\">DigitalWorld.com Return Policy:<span class=\"a-letter-space\" style=\"display: inline-block; width: 0.385em;\"></span>You may return any new computer purchased from DigitalWorld.com that is \"dead on arrival,\" arrives in damaged condition, or is still in unopened boxes, for a full refund within 30 days of purchase. DigitalWorld.com reserves the right to test \"dead on arrival\" returns and impose a customer fee equal to 15 percent of the product sales price if the customer misrepresents the condition of the product. Any returned computer that is damaged through customer misuse, is missing parts, or is in unsellable condition due to customer tampering will result in the customer being charged a higher restocking fee based on the condition of the product. Amazon.com will not accept returns of any desktop or notebook computer more than 30 days after you receive the shipment. New, used, and refurbished products purchased from Marketplace vendors are subject to the returns policy of the individual vendor.<table id=\"productDetails_warranty_support_sections\" class=\"a-keyvalue prodDetTable\" role=\"presentation\" style=\"margin-bottom: 22px; width: 704.594px; border-bottom: 1px solid rgb(213, 217, 217); table-layout: fixed; padding: 0px;\"></table></div><div class=\"a-section table-padding\" style=\"margin-bottom: 0px; margin-left: 12px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\">Manufacturer’s warranty can be requested from customer service.&nbsp;<a href=\"https://www.amazon.com/gp/help/customer/display.html/ref=help_search_1-1?nodeId=201596310\" target=\"_blank\" style=\"color: rgb(33, 98, 161); font-family: Arial;\">Click here</a>&nbsp;to make a request to customer service.</div>', 0, 0, 1, 108),
(111, 'Intel® Core™ i7-14700K Processor', '', '349', 5, 'product-featured-111.jpg', '<ul class=\"a-unordered-list a-vertical a-spacing-mini\" style=\"margin-right: 0px; margin-bottom: 0px; margin-left: 18px; color: rgb(15, 17, 17); padding: 0px; font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\"><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Game Without Compromise. Play harder and work smarter with Intel Core 14th Gen processors</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">20 cores (8 P-cores plus 12 E-cores) and 28 threads. Integrated Intel UHD Graphics 770 included</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Up to 5.6 GHz with Turbo Boost Max Technology 3.0 gives you smooth game play, high frame rates, and rapid responsiveness</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Compatible with Intel 600-series (with potential BIOS update) or 700-series chipset-based motherboards</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">DDR4 and DDR5 platform support cuts your load times and gives you the space to run the most demanding games</span></li></ul>', '<p>Intel® Core™ i7-14700K New Gaming Desktop Processor 20 cores (8 P-cores + 12 E-cores) with Integrated Graphics - Unlocked</p>', '<table class=\"a-normal a-spacing-micro\" role=\"list\" style=\"width: 666.969px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px; background-color: rgb(255, 255, 255); margin-bottom: 0px !important;\"><tbody><tr class=\"a-spacing-small po-brand\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Brand</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">Intel</span></td></tr><tr class=\"a-spacing-small po-cpu_model.manufacturer\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Manufacturer</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">Intel</span></td></tr><tr class=\"a-spacing-small po-cpu_model.family\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Model</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">Core i7</span></td></tr><tr class=\"a-spacing-small po-cpu_model.speed\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Speed</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">5.6 GHz</span></td></tr><tr class=\"a-spacing-small po-cpu_model.socket\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-end: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Socket</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; padding-block-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">LGA 771</span></td></tr></tbody></table>', '', '<div class=\"a-section table-padding\" style=\"margin-bottom: 22px; margin-left: 12px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\">DigitalWorld.com Return Policy:<span class=\"a-letter-space\" style=\"display: inline-block; width: 0.385em;\"></span>You may return any new computer purchased from DigitalWorld.com that is \"dead on arrival,\" arrives in damaged condition, or is still in unopened boxes, for a full refund within 30 days of purchase. DigitalWorld.com reserves the right to test \"dead on arrival\" returns and impose a customer fee equal to 15 percent of the product sales price if the customer misrepresents the condition of the product. Any returned computer that is damaged through customer misuse, is missing parts, or is in unsellable condition due to customer tampering will result in the customer being charged a higher restocking fee based on the condition of the product. Amazon.com will not accept returns of any desktop or notebook computer more than 30 days after you receive the shipment. New, used, and refurbished products purchased from Marketplace vendors are subject to the returns policy of the individual vendor.<table id=\"productDetails_warranty_support_sections\" class=\"a-keyvalue prodDetTable\" role=\"presentation\" style=\"margin-bottom: 22px; width: 704.594px; border-bottom: 1px solid rgb(213, 217, 217); table-layout: fixed; padding: 0px;\"></table></div><div class=\"a-section table-padding\" style=\"margin-bottom: 0px; margin-left: 12px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\">Manufacturer’s warranty can be requested from customer service.&nbsp;<a href=\"https://www.amazon.com/gp/help/customer/display.html/ref=help_search_1-1?nodeId=201596310\" target=\"_blank\" style=\"color: rgb(33, 98, 161); font-family: Arial;\">Click here</a>&nbsp;to make a request to customer service.</div>', 0, 0, 1, 108);
INSERT INTO `tbl_product` (`p_id`, `p_name`, `p_old_price`, `p_current_price`, `p_qty`, `p_featured_photo`, `p_description`, `p_short_description`, `p_feature`, `p_condition`, `p_return_policy`, `p_total_view`, `p_is_featured`, `p_is_active`, `ecat_id`) VALUES
(112, 'Intel® Core™ i5-12400 Processor', '', '215', 2, 'product-featured-112.jpg', '<ul class=\"a-unordered-list a-vertical a-spacing-mini\" style=\"margin-right: 0px; margin-bottom: 0px; margin-left: 18px; color: rgb(15, 17, 17); padding: 0px; font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px;\"><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Intel Core i5 2.50 GHz processor offers hyper-threading architecture that delivers high performance for demanding applications with improved onboard graphics and turbo boost</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">The processor features Socket LGA-1700 socket for installation on the PCB</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Its 18 MB of L3 cache is good enough to carry routine data and process them in a flash giving you fast and smooth performance</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Built-in Intel UHD Graphics 730 controller for improved graphics and visual quality. Supports up to 4 monitors.</span></li></ul>', '<p>Intel Core i5-12400 Desktop Processor 18M Cache, up to 4.40 GHz</p>', '<table class=\"a-normal a-spacing-micro\" role=\"list\" style=\"width: 666.969px; color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px; background-color: rgb(255, 255, 255); margin-bottom: 0px !important;\"><tbody><tr class=\"a-spacing-small po-brand\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Brand</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">Intel</span></td></tr><tr class=\"a-spacing-small po-cpu_model.manufacturer\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Manufacturer</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">Intel</span></td></tr><tr class=\"a-spacing-small po-cpu_model.family\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Model</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">Core i5</span></td></tr><tr class=\"a-spacing-small po-cpu_model.speed\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Speed</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">2.5 GHz</span></td></tr><tr class=\"a-spacing-small po-cpu_model.socket\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-end: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Socket</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; padding-block-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">1700</span></td></tr></tbody></table>', '', '<div class=\"a-section table-padding\" style=\"margin-bottom: 22px; margin-left: 12px; color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px;\">DigitalWorld.com Return Policy:<span class=\"a-letter-space\" style=\"display: inline-block; width: 0.385em;\"></span>You may return any new computer purchased from DigitalWorld.com that is \"dead on arrival,\" arrives in damaged condition, or is still in unopened boxes, for a full refund within 30 days of purchase. DigitalWorld.com reserves the right to test \"dead on arrival\" returns and impose a customer fee equal to 15 percent of the product sales price if the customer misrepresents the condition of the product. Any returned computer that is damaged through customer misuse, is missing parts, or is in unsellable condition due to customer tampering will result in the customer being charged a higher restocking fee based on the condition of the product. Amazon.com will not accept returns of any desktop or notebook computer more than 30 days after you receive the shipment. New, used, and refurbished products purchased from Marketplace vendors are subject to the returns policy of the individual vendor.<table id=\"productDetails_warranty_support_sections\" class=\"a-keyvalue prodDetTable\" role=\"presentation\" style=\"margin-bottom: 22px; width: 704.594px; border-bottom: 1px solid rgb(213, 217, 217); table-layout: fixed; padding: 0px;\"></table></div><div class=\"a-section table-padding\" style=\"margin-bottom: 0px; margin-left: 12px; color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px;\">Manufacturer’s warranty can be requested from customer service. <a href=\"https://www.amazon.com/gp/help/customer/display.html/ref=help_search_1-1?nodeId=201596310\" target=\"_blank\" style=\"color: rgb(33, 98, 161); font-family: Arial;\">Click here</a> to make a request to customer service.</div>', 0, 0, 1, 107),
(113, 'Intel® Core™ Ultra 5 Processor', '231', '157.18', 9, 'product-featured-113.jpg', '<ul class=\"a-unordered-list a-vertical a-spacing-mini\" style=\"margin-right: 0px; margin-bottom: 0px; margin-left: 18px; color: rgb(15, 17, 17); padding: 0px; font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\"><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">10 cores (6 P-cores + 4 E-cores) and 14 threads.</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Performance hybrid architecture integrates two core microarchitectures, prioritizing and distributing workloads to optimize performance</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Up to 4.9 GHz. 22 MB Cache</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Compatible with Intel 800 series chipset-based motherboards</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">PCIe 5.0 &amp; 4.0 support. Intel Optane Memory support. No thermal solution included. Discrete graphics required</span></li></ul>', '<p>Intel® Core™ Ultra 5 Desktop Processor 225F 10 cores (6 P-cores + 4 E-cores) up to 4.9 GHz</p>', '<table class=\"a-normal a-spacing-micro\" role=\"list\" style=\"width: 666.969px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px; background-color: rgb(255, 255, 255); margin-bottom: 0px !important;\"><tbody><tr class=\"a-spacing-small po-brand\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Brand</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">Intel</span></td></tr><tr class=\"a-spacing-small po-cpu_model.manufacturer\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Manufacturer</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">Intel</span></td></tr><tr class=\"a-spacing-small po-cpu_model.family\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Model</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">Intel Core Ultra 5</span></td></tr><tr class=\"a-spacing-small po-cpu_model.speed\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Speed</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">4.4 GHz</span></td></tr><tr class=\"a-spacing-small po-cpu_model.socket\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-end: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Socket</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; padding-block-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">LGA 1851</span></td></tr></tbody></table>', '', '<div class=\"a-section table-padding\" style=\"margin-bottom: 22px; margin-left: 12px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\">DigitalWorld.com Return Policy:<span class=\"a-letter-space\" style=\"display: inline-block; width: 0.385em;\"></span>You may return any new computer purchased from DigitalWorld.com that is \"dead on arrival,\" arrives in damaged condition, or is still in unopened boxes, for a full refund within 30 days of purchase. DigitalWorld.com reserves the right to test \"dead on arrival\" returns and impose a customer fee equal to 15 percent of the product sales price if the customer misrepresents the condition of the product. Any returned computer that is damaged through customer misuse, is missing parts, or is in unsellable condition due to customer tampering will result in the customer being charged a higher restocking fee based on the condition of the product. Amazon.com will not accept returns of any desktop or notebook computer more than 30 days after you receive the shipment. New, used, and refurbished products purchased from Marketplace vendors are subject to the returns policy of the individual vendor.<table id=\"productDetails_warranty_support_sections\" class=\"a-keyvalue prodDetTable\" role=\"presentation\" style=\"margin-bottom: 22px; width: 704.594px; border-bottom: 1px solid rgb(213, 217, 217); table-layout: fixed; padding: 0px;\"></table></div><div class=\"a-section table-padding\" style=\"margin-bottom: 0px; margin-left: 12px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\">Manufacturer’s warranty can be requested from customer service.&nbsp;<a href=\"https://www.amazon.com/gp/help/customer/display.html/ref=help_search_1-1?nodeId=201596310\" target=\"_blank\" style=\"color: rgb(33, 98, 161); font-family: Arial;\">Click here</a>&nbsp;to make a request to customer service.</div>', 0, 1, 1, 107),
(114, 'AMD Ryzen 3 3200G 4-core unlocked processor', '', '66.59', 12, 'product-featured-114.jpg', '<ul class=\"a-unordered-list a-vertical a-spacing-mini\" style=\"margin-right: 0px; margin-bottom: 0px; margin-left: 18px; color: rgb(15, 17, 17); padding: 0px; font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\"><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Includes advanced Radeon Vega 8 graphics, no expensive Graphics card required</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Can deliver smooth high definition performance in the world\'s most popular games</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">4 processing cores, bundled with the quiet AMD Wraith stealth cooler</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">4.0 GHz max Boost, unlocked for overclocking, 6 MB Cache, DDR 2933 support</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">For the advanced socket AM4 platform. Base Clock 3.6 GHz</span></li></ul>', '<p>AMD Ryzen 3 3200G 4-core unlocked desktop processor with Radeon Graphics</p>', '<table class=\"a-normal a-spacing-micro\" role=\"list\" style=\"width: 666.969px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px; background-color: rgb(255, 255, 255); margin-bottom: 0px !important;\"><tbody><tr class=\"a-spacing-small po-brand\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Brand</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">AMD</span></td></tr><tr class=\"a-spacing-small po-cpu_model.manufacturer\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Manufacturer</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">AMD</span></td></tr><tr class=\"a-spacing-small po-cpu_model.family\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Model</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">Ryzen 3 2200G</span></td></tr><tr class=\"a-spacing-small po-cpu_model.speed\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Speed</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">4 GHz</span></td></tr><tr class=\"a-spacing-small po-cpu_model.socket\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-end: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Socket</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; padding-block-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">Socket AM4</span></td></tr></tbody></table>', '', '<div class=\"a-section table-padding\" style=\"margin-bottom: 22px; margin-left: 12px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\">DigitalWorld.com Return Policy:<span class=\"a-letter-space\" style=\"display: inline-block; width: 0.385em;\"></span>You may return any new computer purchased from DigitalWorld.com that is \"dead on arrival,\" arrives in damaged condition, or is still in unopened boxes, for a full refund within 30 days of purchase. DigitalWorld.com reserves the right to test \"dead on arrival\" returns and impose a customer fee equal to 15 percent of the product sales price if the customer misrepresents the condition of the product. Any returned computer that is damaged through customer misuse, is missing parts, or is in unsellable condition due to customer tampering will result in the customer being charged a higher restocking fee based on the condition of the product. Amazon.com will not accept returns of any desktop or notebook computer more than 30 days after you receive the shipment. New, used, and refurbished products purchased from Marketplace vendors are subject to the returns policy of the individual vendor.<table id=\"productDetails_warranty_support_sections\" class=\"a-keyvalue prodDetTable\" role=\"presentation\" style=\"margin-bottom: 22px; width: 704.594px; border-bottom: 1px solid rgb(213, 217, 217); table-layout: fixed; padding: 0px;\"></table></div><div class=\"a-section table-padding\" style=\"margin-bottom: 0px; margin-left: 12px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\">Manufacturer’s warranty can be requested from customer service.&nbsp;<a href=\"https://www.amazon.com/gp/help/customer/display.html/ref=help_search_1-1?nodeId=201596310\" target=\"_blank\" style=\"color: rgb(33, 98, 161); font-family: Arial;\">Click here</a>&nbsp;to make a request to customer service.</div>', 0, 0, 1, 110),
(115, 'AMD Ryzen 5 3600 6-Core Unlocked Processor', '72.89', '67', 4, 'product-featured-115.jpg', '<ul class=\"a-unordered-list a-vertical a-spacing-mini\" style=\"margin-right: 0px; margin-bottom: 0px; margin-left: 18px; color: rgb(15, 17, 17); padding: 0px; font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\"><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">The world\'s most advanced processor in the desktop PC gaming segment</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Can deliver ultra-fast 100+ FPS performance in the world\'s most popular games</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">6 cores and 12 processing threads bundled with the quiet AMD wraith stealth cooler max temps 95°C</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">4 2 GHz max Boost unlocked for overclocking 35 MB of game Cache DDR4 3200 support</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">For the advanced socket AM4 platform can support PCIe 4 0 on x570 motherboards. OS Support-Windows 10 - 64-Bit Edition, RHEL x86 64-Bit, Ubuntu x86 64-Bit. Note-Operating System (OS) support will vary by manufacturer</span></li></ul>', '<p>AMD Ryzen 5 3600 6-Core, 12-Thread Unlocked Desktop Processor with Wraith Stealth Cooler</p>', '<table class=\"a-normal a-spacing-micro\" role=\"list\" style=\"width: 666.969px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px; background-color: rgb(255, 255, 255); margin-bottom: 0px !important;\"><tbody><tr class=\"a-spacing-small po-brand\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Brand</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">AMD</span></td></tr><tr class=\"a-spacing-small po-cpu_model.manufacturer\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Manufacturer</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">AMD</span></td></tr><tr class=\"a-spacing-small po-cpu_model.family\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Model</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">Ryzen 5 3600</span></td></tr><tr class=\"a-spacing-small po-cpu_model.speed\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Speed</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">4.2 GHz</span></td></tr><tr class=\"a-spacing-small po-cpu_model.socket\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-end: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Socket</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; padding-block-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">Socket AM4</span></td></tr></tbody></table>', '', '<div class=\"a-section table-padding\" style=\"margin-bottom: 22px; margin-left: 12px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\">DigitalWorld.com Return Policy:<span class=\"a-letter-space\" style=\"display: inline-block; width: 0.385em;\"></span>You may return any new computer purchased from DigitalWorld.com that is \"dead on arrival,\" arrives in damaged condition, or is still in unopened boxes, for a full refund within 30 days of purchase. DigitalWorld.com reserves the right to test \"dead on arrival\" returns and impose a customer fee equal to 15 percent of the product sales price if the customer misrepresents the condition of the product. Any returned computer that is damaged through customer misuse, is missing parts, or is in unsellable condition due to customer tampering will result in the customer being charged a higher restocking fee based on the condition of the product. Amazon.com will not accept returns of any desktop or notebook computer more than 30 days after you receive the shipment. New, used, and refurbished products purchased from Marketplace vendors are subject to the returns policy of the individual vendor.<table id=\"productDetails_warranty_support_sections\" class=\"a-keyvalue prodDetTable\" role=\"presentation\" style=\"margin-bottom: 22px; width: 704.594px; border-bottom: 1px solid rgb(213, 217, 217); table-layout: fixed; padding: 0px;\"></table></div><div class=\"a-section table-padding\" style=\"margin-bottom: 0px; margin-left: 12px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\">Manufacturer’s warranty can be requested from customer service.&nbsp;<a href=\"https://www.amazon.com/gp/help/customer/display.html/ref=help_search_1-1?nodeId=201596310\" target=\"_blank\" style=\"color: rgb(33, 98, 161); font-family: Arial;\">Click here</a>&nbsp;to make a request to customer service.</div>', 1, 1, 1, 111),
(116, 'AMD Ryzen™ 7 5800XT 8-Core Unlocked Processor', '', '183', 5, 'product-featured-116.jpg', '<ul class=\"a-unordered-list a-vertical a-spacing-mini\" style=\"margin-right: 0px; margin-bottom: 0px; margin-left: 18px; color: rgb(15, 17, 17); padding: 0px; font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px;\"><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Powerful Gaming Performance</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">8 Cores and 16 processing threads, based on AMD \"Zen 3\" architecture</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">4.8 GHz Max Boost, unlocked for overclocking, 36 MB cache, DDR4-3200 support</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">For the AMD Socket AM4 platform, with PCIe 4.0 support</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">AMD Wraith Prism Cooler with RGB LED included</span></li></ul>', '<div id=\"productDescription_feature_div\" class=\"celwidget pd_rd_w-UmB6h pd_rd_r-J6HDV6GD26GF19MJZ9DA pd_rd_wg-G13Wf\" data-feature-name=\"productDescription\" data-csa-c-type=\"widget\" data-csa-c-content-id=\"productDescription\" data-csa-c-slot-id=\"productDescription_feature_div\" data-csa-c-asin=\"\" data-csa-c-is-in-initial-active-row=\"false\" data-csa-c-id=\"vui9ix-w9nqak-pj9v7u-mz3f92\" data-cel-widget=\"productDescription_feature_div\" style=\"color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px;\"><div data-feature-name=\"productDescription\" data-template-name=\"productDescription\" id=\"productDescription_feature_div\" class=\"a-row feature\" data-cel-widget=\"productDescription_feature_div\" style=\"width: 1464px;\"><div id=\"productDescription\" class=\"a-section a-spacing-small\" style=\"margin: 0.5em 0px 0em 25px; color: rgb(51, 51, 51); overflow-wrap: break-word; font-size: small; line-height: initial;\"><p style=\"padding: 0px; margin-top: 0em; margin-bottom: 1em; margin-left: 1em;\">The AMD Ryzen 5000 series delivers proven \"Zen 3\" performance</p></div></div></div><div id=\"va-related-videos-widget_feature_div\" class=\"celwidget pd_rd_w-2VpBJ pd_rd_r-J6HDV6GD26GF19MJZ9DA pd_rd_wg-G13Wf\" data-feature-name=\"va-related-videos-widget\" data-csa-c-type=\"widget\" data-csa-c-content-id=\"va-related-videos-widget\" data-csa-c-slot-id=\"va-related-videos-widget_feature_div\" data-csa-c-asin=\"\" data-csa-c-is-in-initial-active-row=\"false\" data-csa-c-id=\"6hdz6z-jnmmjl-9qyg9x-s9q0vz\" data-cel-widget=\"va-related-videos-widget_feature_div\" style=\"color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px;\"><div class=\"celwidget c-f\" cel_widget_id=\"vse-vw-dp-card_DetailPage_4\" data-csa-op-log-render=\"\" data-csa-c-content-id=\"DsUnknown\" data-csa-c-slot-id=\"DsUnknown-5\" data-csa-c-type=\"widget\" data-csa-c-painter=\"vse-vw-dp-card-cards\" data-csa-c-id=\"endzab-vc7fwj-u1qzps-km62lr\" data-cel-widget=\"vse-vw-dp-card_DetailPage_4\"><div class=\"a-cardui-deck\" data-a-remove-bottom-gutter=\"true\" id=\"CardInstance8YNPmC00DCrFkquIaR5zhA\" data-card-metrics-id=\"vse-vw-dp-card_DetailPage_4\" name=\"a-cardui-deck-autoname-0\" data-mix-claimed=\"true\" style=\"background-color: transparent; padding-top: 0.1px; padding-bottom: 0.1px;\"><div data-elementid=\"vse-vw-dp-widget-container\" class=\"a-cardui vse-vw-dp _dnNlL_vseVideoWidgetContainer_3HDIT vse-video-widget-dp-container vse-video-widget-container ive-lite-player\" data-a-card-type=\"basic\" name=\"a-cardui-deck-autoname-0-card0\" style=\"margin-top: 20px; margin-bottom: 20px; overflow: auto; padding: 20px 0px 15px; position: relative;\"><div class=\"a-cardui-body\" style=\"padding: 0px 0px 5px; position: relative;\"><div class=\"vse-vwdp-video-block-wrapper\" data-element-id=\"rv-popover-container\" data-csa-c-content-id=\"vse-video-widget-detail-page\" data-csa-c-type=\"widget\" data-csa-c-cs-type=\"vse\" data-csa-c-painter=\"va-related-videos-widget\" data-csa-c-component=\"vse-video-widget-detail-page\" data-csa-c-slot-id=\"btf.vse\" data-csa-op-log-render=\"\" data-csa-c-id=\"gd0anw-86f4wp-6hcb4z-h3ol7y\"><div class=\"_dnNlL_vseHeroWidgetHeaderBlock_25gLA a-spacing-small\" data-csa-c-type=\"uxElement\" data-csa-c-element-id=\"vse-cards-vw-dp-widget-title-hero\" data-csa-c-element-type=\"header\" data-csa-c-id=\"y7c8e-8588fu-x0n07l-fwk5ln\" style=\"display: flex; margin-top: auto; margin-right: auto; margin-left: auto; max-width: 1464px; min-width: 964px; padding-bottom: 16px; margin-bottom: 0px !important;\"></div></div></div></div></div></div></div><div id=\"aplus_feature_div\" class=\"celwidget pd_rd_w-UGtqQ pd_rd_r-J6HDV6GD26GF19MJZ9DA pd_rd_wg-G13Wf\" data-feature-name=\"aplus\" data-csa-c-type=\"widget\" data-csa-c-content-id=\"aplus\" data-csa-c-slot-id=\"aplus_feature_div\" data-csa-c-asin=\"\" data-csa-c-is-in-initial-active-row=\"false\" data-csa-c-id=\"s5roox-xbbb8y-9gtvum-5m7xx\" data-cel-widget=\"aplus_feature_div\" style=\"box-sizing: border-box; color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; white-space: normal; background-color: rgb(255, 255, 255); text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial;\"></div><div id=\"productDocuments_feature_div\" class=\"celwidget pd_rd_w-E4AWn pd_rd_r-J6HDV6GD26GF19MJZ9DA pd_rd_wg-G13Wf\" data-feature-name=\"productDocuments\" data-csa-c-type=\"widget\" data-csa-c-content-id=\"productDocuments\" data-csa-c-slot-id=\"productDocuments_feature_div\" data-csa-c-asin=\"\" data-csa-c-is-in-initial-active-row=\"false\" data-csa-c-id=\"xmq80h-nt6qkb-hvqmue-ivxqcj\" data-cel-widget=\"productDocuments_feature_div\" style=\"box-sizing: border-box; color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; white-space: normal; background-color: rgb(255, 255, 255); text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial;\"></div>', '<table class=\"a-normal a-spacing-micro\" role=\"list\" style=\"width: 666.969px; color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px; background-color: rgb(255, 255, 255); margin-bottom: 0px !important;\"><tbody><tr class=\"a-spacing-small po-brand\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Brand</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">AMD</span></td></tr><tr class=\"a-spacing-small po-cpu_model.manufacturer\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Manufacturer</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">AMD</span></td></tr><tr class=\"a-spacing-small po-cpu_model.family\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Model</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">Ryzen 7</span></td></tr><tr class=\"a-spacing-small po-cpu_model.speed\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Speed</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">3.8 GHz</span></td></tr><tr class=\"a-spacing-small po-cpu_model.socket\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-end: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Socket</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; padding-block-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">Socket AM4</span></td></tr></tbody></table>', '', '<div class=\"a-section table-padding\" style=\"margin-bottom: 22px; margin-left: 12px; color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px;\">DigitalWorld.com Return Policy:<span class=\"a-letter-space\" style=\"display: inline-block; width: 0.385em;\"></span>You may return any new computer purchased from DigitalWorld.com that is \"dead on arrival,\" arrives in damaged condition, or is still in unopened boxes, for a full refund within 30 days of purchase. DigitalWorld.com reserves the right to test \"dead on arrival\" returns and impose a customer fee equal to 15 percent of the product sales price if the customer misrepresents the condition of the product. Any returned computer that is damaged through customer misuse, is missing parts, or is in unsellable condition due to customer tampering will result in the customer being charged a higher restocking fee based on the condition of the product. Amazon.com will not accept returns of any desktop or notebook computer more than 30 days after you receive the shipment. New, used, and refurbished products purchased from Marketplace vendors are subject to the returns policy of the individual vendor.<table id=\"productDetails_warranty_support_sections\" class=\"a-keyvalue prodDetTable\" role=\"presentation\" style=\"margin-bottom: 22px; width: 704.594px; border-bottom: 1px solid rgb(213, 217, 217); table-layout: fixed; padding: 0px;\"></table></div><div class=\"a-section table-padding\" style=\"margin-bottom: 0px; margin-left: 12px; color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px;\">Manufacturer’s warranty can be requested from customer service. <a href=\"https://www.amazon.com/gp/help/customer/display.html/ref=help_search_1-1?nodeId=201596310\" target=\"_blank\" style=\"color: rgb(33, 98, 161); font-family: Arial;\">Click here</a> to make a request to customer service.</div>', 0, 0, 1, 112);
INSERT INTO `tbl_product` (`p_id`, `p_name`, `p_old_price`, `p_current_price`, `p_qty`, `p_featured_photo`, `p_description`, `p_short_description`, `p_feature`, `p_condition`, `p_return_policy`, `p_total_view`, `p_is_featured`, `p_is_active`, `ecat_id`) VALUES
(117, 'AMD Ryzen 9 7900X 12-Core Unlocked Processor', '', '323.99', 5, 'product-featured-117.jpg', '<ul class=\"a-unordered-list a-vertical a-spacing-mini\" style=\"margin-right: 0px; margin-bottom: 0px; margin-left: 18px; color: rgb(15, 17, 17); padding: 0px; font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\"><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Processor is versatile, reliable, and offers convenient usage with high speed</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Ryzen 9 product line processor for your convenience and optimal usage</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">5 nm process technology for reliable performance with maximum productivity</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Dodeca-core (12 Core) processor core allows multitasking with great reliability and fast processing speed</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">12 MB L2 plus 64 MB L3 cache memory provides excellent hit rate in short access time enabling improved system performance</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Processor with 4.70 GHz clock speed for faster, efficient execution of cycles per second to ensure maximum usability</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Comes with AMD Radeon Graphics controller for stunning picture quality</span></li></ul>', '<p>AMD Ryzen 9 7900X 12-Core, 24-Thread Unlocked Desktop Processor</p>', '<table class=\"a-normal a-spacing-micro\" role=\"list\" style=\"width: 666.969px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px; background-color: rgb(255, 255, 255); margin-bottom: 0px !important;\"><tbody><tr class=\"a-spacing-small po-brand\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Brand</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">AMD</span></td></tr><tr class=\"a-spacing-small po-cpu_model.manufacturer\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Manufacturer</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">AMD</span></td></tr><tr class=\"a-spacing-small po-cpu_model.family\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Model</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">Ryzen 9</span></td></tr><tr class=\"a-spacing-small po-cpu_model.speed\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Speed</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">5.6 GHz</span></td></tr><tr class=\"a-spacing-small po-cpu_model.socket\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-end: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">CPU Socket</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; padding-block-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">Socket AM5</span></td></tr></tbody></table>', '', '<div class=\"a-section table-padding\" style=\"margin-bottom: 22px; margin-left: 12px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\">DigitalWorld.com Return Policy:<span class=\"a-letter-space\" style=\"display: inline-block; width: 0.385em;\"></span>You may return any new computer purchased from DigitalWorld.com that is \"dead on arrival,\" arrives in damaged condition, or is still in unopened boxes, for a full refund within 30 days of purchase. DigitalWorld.com reserves the right to test \"dead on arrival\" returns and impose a customer fee equal to 15 percent of the product sales price if the customer misrepresents the condition of the product. Any returned computer that is damaged through customer misuse, is missing parts, or is in unsellable condition due to customer tampering will result in the customer being charged a higher restocking fee based on the condition of the product. Amazon.com will not accept returns of any desktop or notebook computer more than 30 days after you receive the shipment. New, used, and refurbished products purchased from Marketplace vendors are subject to the returns policy of the individual vendor.<table id=\"productDetails_warranty_support_sections\" class=\"a-keyvalue prodDetTable\" role=\"presentation\" style=\"margin-bottom: 22px; width: 704.594px; border-bottom: 1px solid rgb(213, 217, 217); table-layout: fixed; padding: 0px;\"></table></div><div class=\"a-section table-padding\" style=\"margin-bottom: 0px; margin-left: 12px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\">Manufacturer’s warranty can be requested from customer service.&nbsp;<a href=\"https://www.amazon.com/gp/help/customer/display.html/ref=help_search_1-1?nodeId=201596310\" target=\"_blank\" style=\"color: rgb(33, 98, 161); font-family: Arial;\">Click here</a>&nbsp;to make a request to customer service.</div>', 0, 0, 1, 113),
(118, 'PNY NVIDIA GeForce RTX™ 5070 Epic-X™ ARGB OC Triple Fan', '699.99', '579.99', 3, 'product-featured-118.jpg', '<ul class=\"a-unordered-list a-vertical a-spacing-mini\" style=\"margin-right: 0px; margin-bottom: 0px; margin-left: 18px; color: rgb(15, 17, 17); padding: 0px; font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px;\"><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">DLSS is a revolutionary suite of neural rendering technologies that uses AI to boost FPS, reduce latency, and improve image quality.</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Fifth-Gen Tensor Cores, New Streaming Multiprocessors, Fourth-Gen Ray Tracing Cores</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Reflex technologies optimize the graphics pipeline for ultimate responsiveness, providing faster target acquisition, quicker reaction times, and improved aim precision in competitive games.</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Upgrade to advanced AI with NVIDIA GeForce RTX GPUs and accelerate your gaming, creating, productivity, and development. Thanks to built-in AI processors, you get world-leading AI technology powering your Windows PC.</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Experience RTX accelerations in top creative apps, world-class NVIDIA Studio drivers engineered and continually updated to provide maximum stability, and a suite of exclusive tools that harness the power of RTX for AI-assisted creative workflows.</span></li></ul>', '<div id=\"productDescription_feature_div\" class=\"celwidget pd_rd_w-sz2LF pd_rd_r-KYG98NN91NVWNB0ADKJ0 pd_rd_wg-pOouG\" data-feature-name=\"productDescription\" data-csa-c-type=\"widget\" data-csa-c-content-id=\"productDescription\" data-csa-c-slot-id=\"productDescription_feature_div\" data-csa-c-asin=\"\" data-csa-c-is-in-initial-active-row=\"false\" data-csa-c-id=\"z6kdky-8cqxqd-oep2sw-ghi1us\" data-cel-widget=\"productDescription_feature_div\" style=\"color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px;\"><div data-feature-name=\"productDescription\" data-template-name=\"productDescription\" id=\"productDescription_feature_div\" class=\"a-row feature\" data-cel-widget=\"productDescription_feature_div\" style=\"width: 1464px;\"><div id=\"productDescription\" class=\"a-section a-spacing-small\" style=\"margin: 0.5em 0px 0em 25px; color: rgb(51, 51, 51); overflow-wrap: break-word; font-size: small; line-height: initial;\"><p style=\"padding: 0px; margin-top: 0em; margin-bottom: 1em; margin-left: 1em;\">Get game-changing performance with the GeForce RTX™ 5070, powered by NVIDIA Blackwell. Game at high frame rates with DLSS 4, supercharge your creativity with NVIDIA Studio, and enable new experiences with the power of AI.</p></div></div></div><div id=\"aplusSustainabilityStory_feature_div\" class=\"celwidget pd_rd_w-2yGL5 pd_rd_r-KYG98NN91NVWNB0ADKJ0 pd_rd_wg-pOouG\" data-feature-name=\"aplusSustainabilityStory\" data-csa-c-type=\"widget\" data-csa-c-content-id=\"aplusSustainabilityStory\" data-csa-c-slot-id=\"aplusSustainabilityStory_feature_div\" data-csa-c-asin=\"\" data-csa-c-is-in-initial-active-row=\"false\" data-csa-c-id=\"6g49vu-7spk0x-n5rp2q-ati09f\" data-cel-widget=\"aplusSustainabilityStory_feature_div\" style=\"color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px;\"></div><div id=\"productDocuments_feature_div\" class=\"celwidget pd_rd_w-o6AqM pd_rd_r-KYG98NN91NVWNB0ADKJ0 pd_rd_wg-pOouG\" data-feature-name=\"productDocuments\" data-csa-c-type=\"widget\" data-csa-c-content-id=\"productDocuments\" data-csa-c-slot-id=\"productDocuments_feature_div\" data-csa-c-asin=\"\" data-csa-c-is-in-initial-active-row=\"false\" data-csa-c-id=\"tq3e10-g90owj-ie7413-m30w43\" data-cel-widget=\"productDocuments_feature_div\" style=\"color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px;\"></div><div id=\"postPurchaseWhatsInTheBox_MP_feature_div\" class=\"celwidget pd_rd_w-Zoydb pd_rd_r-KYG98NN91NVWNB0ADKJ0 pd_rd_wg-pOouG\" data-feature-name=\"postPurchaseWhatsInTheBox_MP\" data-csa-c-type=\"widget\" data-csa-c-content-id=\"postPurchaseWhatsInTheBox_MP\" data-csa-c-slot-id=\"postPurchaseWhatsInTheBox_MP_feature_div\" data-csa-c-asin=\"\" data-csa-c-is-in-initial-active-row=\"false\" data-csa-c-id=\"tydtmb-b3ejne-13ytm9-6l2zqi\" data-cel-widget=\"postPurchaseWhatsInTheBox_MP_feature_div\" style=\"color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px;\"><div id=\"whatsInTheBoxDeck\" class=\"a-section a-spacing-base celwidget\" data-csa-c-id=\"jpvxk9-ytplet-9hesdt-xn5o3x\" data-cel-widget=\"whatsInTheBoxDeck\" style=\"margin-bottom: 0px;\"><hr aria-hidden=\"true\" class=\"a-divider-normal bucketDivider\" style=\"box-sizing: border-box; line-height: 19px; margin-top: 0px; clear: left; background: 0px 0px !important; border-top-color: rgb(204, 204, 204) !important; height: 44px !important; margin-bottom: -36px !important;\"><h2 style=\"padding: 0px; margin: 0px; padding-block-end: 0.25rem; text-rendering: optimizelegibility; line-height: 32px; font-weight: 700 !important; font-size: 1.25rem !important; color: rgb(15, 17, 17) !important; font-family: \"Amazon Ember\" !important;\">What\'s in the box</h2><dl id=\"witb-content-list\" class=\"a-definition-list a-vertical a-spacing-none postpurchase-included-components-list-group\" style=\"padding: 0px; margin-right: 0px; margin-left: 18px; margin-bottom: 0px !important;\"><li class=\"postpurchase-included-components-list-item\" style=\"overflow-wrap: break-word;\"><span class=\"a-list-item\">PNY GeForce RTX™ 5070 ARGB OC</span></li><li class=\"postpurchase-included-components-list-item\" style=\"overflow-wrap: break-word;\"><span class=\"a-list-item\">One 16-pin to Two 8-pin Power Cable</span></li></dl></div></div>', '<table class=\"a-normal a-spacing-micro\" role=\"list\" style=\"width: 666.969px; color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px; background-color: rgb(255, 255, 255); margin-bottom: 0px !important;\"></table><table class=\"a-normal a-spacing-micro\" role=\"list\" style=\"width: 666.969px; color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px; background-color: rgb(255, 255, 255); margin-bottom: 0px !important;\"><tbody><tr class=\"a-spacing-small po-graphics_coprocessor\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Graphics Coprocessor</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">NVIDIA GeForce RTX 5070</span></td></tr><tr class=\"a-spacing-small po-brand\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Brand</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">PNY</span></td></tr><tr class=\"a-spacing-small po-graphics_ram.size\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Graphics Ram Size</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">12 GB</span></td></tr><tr class=\"a-spacing-small po-video_output_interface\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Video Output Interface</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">DisplayPort, HDMI</span></td></tr><tr class=\"a-spacing-small po-graphics_processor_manufacturer\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-end: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Graphics Processor Manufacturer</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; padding-block-end: 0px; float: none !important;\"></td></tr></tbody></table>', '', '<div class=\"a-section table-padding\" style=\"margin-bottom: 22px; margin-left: 12px; color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px;\">DigitalWorld.com Return Policy:<span class=\"a-letter-space\" style=\"display: inline-block; width: 0.385em;\"></span>You may return any new computer purchased from DigitalWorld.com that is \"dead on arrival,\" arrives in damaged condition, or is still in unopened boxes, for a full refund within 30 days of purchase. DigitalWorld.com reserves the right to test \"dead on arrival\" returns and impose a customer fee equal to 15 percent of the product sales price if the customer misrepresents the condition of the product. Any returned computer that is damaged through customer misuse, is missing parts, or is in unsellable condition due to customer tampering will result in the customer being charged a higher restocking fee based on the condition of the product. Amazon.com will not accept returns of any desktop or notebook computer more than 30 days after you receive the shipment. New, used, and refurbished products purchased from Marketplace vendors are subject to the returns policy of the individual vendor.<table id=\"productDetails_warranty_support_sections\" class=\"a-keyvalue prodDetTable\" role=\"presentation\" style=\"margin-bottom: 22px; width: 704.594px; border-bottom: 1px solid rgb(213, 217, 217); table-layout: fixed; padding: 0px;\"></table></div><div class=\"a-section table-padding\" style=\"margin-bottom: 0px; margin-left: 12px; color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px;\">Manufacturer’s warranty can be requested from customer service. <a href=\"https://www.amazon.com/gp/help/customer/display.html/ref=help_search_1-1?nodeId=201596310\" target=\"_blank\" style=\"color: rgb(33, 98, 161); font-family: Arial;\">Click here</a> to make a request to customer service.</div>', 15, 1, 1, 114),
(119, 'ASUS Dual GeForce RTX™ 4060 Ti EVO OC Edition 8GB GDDR6', '', '379.22', 1, 'product-featured-119.jpg', '<ul class=\"a-unordered-list a-vertical a-spacing-mini\" style=\"margin-right: 0px; margin-bottom: 0px; margin-left: 18px; color: rgb(15, 17, 17); padding: 0px; font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\"><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Powered by NVIDIA DLSS3, ultra-efficient Ada Lovelace arch, and full ray tracing</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">4th Generation Tensor Cores: Up to 4x performance with DLSS 3 vs. brute-force rendering</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">3rd Generation RT Cores: Up to 2x ray tracing performance</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">OC edition: Boost Clock 2595 MHz (OC Mode)/ 2565 MHz (Default Mode)</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Axial-tech fan design features a smaller fan hub that facilitates longer blades and a barrier ring that increases downward air pressure</span></li></ul>', '<div id=\"productDescription_feature_div\" class=\"celwidget pd_rd_w-yWjz0 pd_rd_r-6TPBDJWWSQXWJ4MT8C28 pd_rd_wg-0D4av\" data-feature-name=\"productDescription\" data-csa-c-type=\"widget\" data-csa-c-content-id=\"productDescription\" data-csa-c-slot-id=\"productDescription_feature_div\" data-csa-c-asin=\"\" data-csa-c-is-in-initial-active-row=\"false\" data-csa-c-id=\"k15ki6-38ojfd-4k17q2-nzn8nv\" data-cel-widget=\"productDescription_feature_div\" style=\"color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\"><div data-feature-name=\"productDescription\" data-template-name=\"productDescription\" id=\"productDescription_feature_div\" class=\"a-row feature\" data-cel-widget=\"productDescription_feature_div\" style=\"width: 1464px;\"><div id=\"productDescription\" class=\"a-section a-spacing-small\" style=\"margin: 0.5em 0px 0em 25px; color: rgb(51, 51, 51); overflow-wrap: break-word; font-size: small; line-height: initial;\"><p style=\"padding: 0px; margin-top: 0em; margin-bottom: 1em; margin-left: 1em;\">The ASUS Dual GeForce RTX™ 4060 Ti EVO 8GB OC is one of the newest additions to the GeForce RTX 40 series lineup. With Axial-tech fan design, 0db technology, and dual ball fan bearings, this GPU will serve as your gateway to AAA gaming with DLSS 3.5 and other NVIDIA technologies. Game faster today with the ASUS Dual GeForce RTX™ 4060 Ti EVO 8GB OC.</p></div></div></div><div id=\"aplusSustainabilityStory_feature_div\" class=\"celwidget pd_rd_w-mcRBT pd_rd_r-6TPBDJWWSQXWJ4MT8C28 pd_rd_wg-0D4av\" data-feature-name=\"aplusSustainabilityStory\" data-csa-c-type=\"widget\" data-csa-c-content-id=\"aplusSustainabilityStory\" data-csa-c-slot-id=\"aplusSustainabilityStory_feature_div\" data-csa-c-asin=\"\" data-csa-c-is-in-initial-active-row=\"false\" data-csa-c-id=\"qk40y6-4n18st-2s1pit-vj46hj\" data-cel-widget=\"aplusSustainabilityStory_feature_div\" style=\"color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\"></div><div id=\"productDocuments_feature_div\" class=\"celwidget pd_rd_w-b1UJN pd_rd_r-6TPBDJWWSQXWJ4MT8C28 pd_rd_wg-0D4av\" data-feature-name=\"productDocuments\" data-csa-c-type=\"widget\" data-csa-c-content-id=\"productDocuments\" data-csa-c-slot-id=\"productDocuments_feature_div\" data-csa-c-asin=\"\" data-csa-c-is-in-initial-active-row=\"false\" data-csa-c-id=\"lcaxeb-fxmv4a-701jh5-ppevpj\" data-cel-widget=\"productDocuments_feature_div\" style=\"color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\"></div><div id=\"postPurchaseWhatsInTheBox_MP_feature_div\" class=\"celwidget pd_rd_w-WrhR2 pd_rd_r-6TPBDJWWSQXWJ4MT8C28 pd_rd_wg-0D4av\" data-feature-name=\"postPurchaseWhatsInTheBox_MP\" data-csa-c-type=\"widget\" data-csa-c-content-id=\"postPurchaseWhatsInTheBox_MP\" data-csa-c-slot-id=\"postPurchaseWhatsInTheBox_MP_feature_div\" data-csa-c-asin=\"\" data-csa-c-is-in-initial-active-row=\"false\" data-csa-c-id=\"lgxotp-ogfckr-9m28oh-x64yxz\" data-cel-widget=\"postPurchaseWhatsInTheBox_MP_feature_div\" style=\"color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\"><div id=\"whatsInTheBoxDeck\" class=\"a-section a-spacing-base celwidget\" data-csa-c-id=\"z9c2tv-mlfgp7-sxj1qk-venp1r\" data-cel-widget=\"whatsInTheBoxDeck\" style=\"margin-bottom: 0px;\"><hr aria-hidden=\"true\" class=\"a-divider-normal bucketDivider\" style=\"box-sizing: border-box; line-height: 19px; margin-top: 0px; clear: left; background: 0px 0px !important; border-top-color: rgb(204, 204, 204) !important; height: 44px !important; margin-bottom: -36px !important;\"><h2 style=\"padding: 0px; margin: 0px; padding-block-end: 0.25rem; text-rendering: optimizelegibility; line-height: 32px; font-weight: 700 !important; font-size: 1.25rem !important; color: rgb(15, 17, 17) !important; font-family: &quot;Amazon Ember&quot; !important;\">What\'s in the box</h2><dl id=\"witb-content-list\" class=\"a-definition-list a-vertical a-spacing-none postpurchase-included-components-list-group\" style=\"padding: 0px; margin-right: 0px; margin-left: 18px; margin-bottom: 0px !important;\"><li class=\"postpurchase-included-components-list-item\" style=\"overflow-wrap: break-word;\"><span class=\"a-list-item\">DUAL-RTX4060TI-O8G-EVO Graphics card</span></li><li class=\"postpurchase-included-components-list-item\" style=\"overflow-wrap: break-word;\"><span class=\"a-list-item\">Speedset up manual</span></li><li class=\"postpurchase-included-components-list-item\" style=\"overflow-wrap: break-word;\"><span class=\"a-list-item\">Thank you card</span></li></dl></div></div>', '<table class=\"a-normal a-spacing-micro\" role=\"list\" style=\"width: 666.969px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px; background-color: rgb(255, 255, 255); margin-bottom: 0px !important;\"><tbody><tr class=\"a-spacing-small po-graphics_coprocessor\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Graphics Coprocessor</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">NVIDIA GeForce RTX 4060 Ti</span></td></tr><tr class=\"a-spacing-small po-brand\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Brand</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">ASUS</span></td></tr><tr class=\"a-spacing-small po-graphics_ram.size\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Graphics Ram Size</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">8 GB</span></td></tr><tr class=\"a-spacing-small po-gpu_clock_speed\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">GPU Clock Speed</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">2595 MHz</span></td></tr><tr class=\"a-spacing-small po-video_output_interface\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-end: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Video Output Interface</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; padding-block-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">DisplayPort, HDMI</span></td></tr></tbody></table>', '', '<div class=\"a-section table-padding\" style=\"margin-bottom: 22px; margin-left: 12px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\">DigitalWorld.com Return Policy:<span class=\"a-letter-space\" style=\"display: inline-block; width: 0.385em;\"></span>You may return any new computer purchased from DigitalWorld.com that is \"dead on arrival,\" arrives in damaged condition, or is still in unopened boxes, for a full refund within 30 days of purchase. DigitalWorld.com reserves the right to test \"dead on arrival\" returns and impose a customer fee equal to 15 percent of the product sales price if the customer misrepresents the condition of the product. Any returned computer that is damaged through customer misuse, is missing parts, or is in unsellable condition due to customer tampering will result in the customer being charged a higher restocking fee based on the condition of the product. Amazon.com will not accept returns of any desktop or notebook computer more than 30 days after you receive the shipment. New, used, and refurbished products purchased from Marketplace vendors are subject to the returns policy of the individual vendor.<table id=\"productDetails_warranty_support_sections\" class=\"a-keyvalue prodDetTable\" role=\"presentation\" style=\"margin-bottom: 22px; width: 704.594px; border-bottom: 1px solid rgb(213, 217, 217); table-layout: fixed; padding: 0px;\"></table></div><div class=\"a-section table-padding\" style=\"margin-bottom: 0px; margin-left: 12px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\">Manufacturer’s warranty can be requested from customer service.&nbsp;<a href=\"https://www.amazon.com/gp/help/customer/display.html/ref=help_search_1-1?nodeId=201596310\" target=\"_blank\" style=\"color: rgb(33, 98, 161); font-family: Arial;\">Click here</a>&nbsp;to make a request to customer service.</div>', 0, 0, 1, 115),
(120, 'GIGABYTE GeForce RTX 3060 Gaming OC 12G (REV2.0)', '354.99', '299.99', 3, 'product-featured-120.jpg', '<ul class=\"a-unordered-list a-vertical a-spacing-mini\" style=\"margin-right: 0px; margin-bottom: 0px; margin-left: 18px; color: rgb(15, 17, 17); padding: 0px; font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\"><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">NVIDIA Ampere Streaming Multiprocessors</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">2nd Generation RT Cores</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">3rd Generation Tensor Cores</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Powered by GeForce RTX 3060.Avoid using unofficial software</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Integrated with 12GB GDDR6 192-bit memory interface</span></li></ul>', '<div id=\"productDescription_feature_div\" class=\"celwidget pd_rd_w-6dzpE pd_rd_r-RYEP9TCX88CY9C0AD5B1 pd_rd_wg-OzSzC\" data-feature-name=\"productDescription\" data-csa-c-type=\"widget\" data-csa-c-content-id=\"productDescription\" data-csa-c-slot-id=\"productDescription_feature_div\" data-csa-c-asin=\"\" data-csa-c-is-in-initial-active-row=\"false\" data-csa-c-id=\"4t2dn3-o2xlt-dv6a4a-jh12p9\" data-cel-widget=\"productDescription_feature_div\" style=\"color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\"><div data-feature-name=\"productDescription\" data-template-name=\"productDescription\" id=\"productDescription_feature_div\" class=\"a-row feature\" data-cel-widget=\"productDescription_feature_div\" style=\"width: 1464px;\"><div id=\"productDescription\" class=\"a-section a-spacing-small\" style=\"margin: 0.5em 0px 0em 25px; color: rgb(51, 51, 51); overflow-wrap: break-word; font-size: small; line-height: initial;\"><p style=\"padding: 0px; margin-top: 0em; margin-bottom: 1em; margin-left: 1em;\">NVIDIA Ampere Streaming Multiprocessors 2nd Generation RT Cores 3rd Generation Tensor Cores Powered by GeForce RTX 3060 Integrated with 12GB GDDR6 192-bit memory interface WINDFORCE 3X Cooling System with alternate spinning fans RGB Fusion 2.0 Protection metal back plate 2x HDMI 2.1, 2x DisplayPort 1.4 Core Clock: 1837 MHz Limited Hash Rate version. Get the ultimate gaming performance with GIGABYTE RTX 3060 Graphics Cards. Powered by NVIDIA\'s 2nd gen RTX architecture and refined with WINDFORCE cooling technology, the GeForce RTX 3060 GAMING OC 12G (rev. 2.0) brings stunning visuals, amazingly fast frame rates, and AI acceleration to games and creative applications with its enhanced RT Cores and Tensor Cores.</p></div></div></div><div id=\"postPurchaseWhatsInTheBox_MP_feature_div\" class=\"celwidget pd_rd_w-cJfaC pd_rd_r-RYEP9TCX88CY9C0AD5B1 pd_rd_wg-OzSzC\" data-feature-name=\"postPurchaseWhatsInTheBox_MP\" data-csa-c-type=\"widget\" data-csa-c-content-id=\"postPurchaseWhatsInTheBox_MP\" data-csa-c-slot-id=\"postPurchaseWhatsInTheBox_MP_feature_div\" data-csa-c-asin=\"\" data-csa-c-is-in-initial-active-row=\"false\" data-csa-c-id=\"jubsm7-9vezel-f79v8c-xyumsd\" data-cel-widget=\"postPurchaseWhatsInTheBox_MP_feature_div\" style=\"color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\"><div id=\"whatsInTheBoxDeck\" class=\"a-section a-spacing-base celwidget\" data-csa-c-id=\"9ondb7-mz0650-ij7azp-whhgwb\" data-cel-widget=\"whatsInTheBoxDeck\" style=\"margin-bottom: 0px;\"><hr aria-hidden=\"true\" class=\"a-divider-normal bucketDivider\" style=\"box-sizing: border-box; line-height: 19px; margin-top: 0px; clear: left; background: 0px 0px !important; border-top-color: rgb(204, 204, 204) !important; height: 44px !important; margin-bottom: -36px !important;\"><h2 style=\"padding: 0px; margin: 0px; padding-block-end: 0.25rem; text-rendering: optimizelegibility; line-height: 32px; font-weight: 700 !important; font-size: 1.25rem !important; color: rgb(15, 17, 17) !important; font-family: &quot;Amazon Ember&quot; !important;\">What\'s in the box</h2><dl id=\"witb-content-list\" class=\"a-definition-list a-vertical a-spacing-none postpurchase-included-components-list-group\" style=\"padding: 0px; margin-right: 0px; margin-left: 18px; margin-bottom: 0px !important;\"><li class=\"postpurchase-included-components-list-item\" style=\"overflow-wrap: break-word;\"><span class=\"a-list-item\">GRAPHIC CARD, USERS MANUAL</span></li></dl></div></div>', '<table class=\"a-normal a-spacing-micro\" role=\"list\" style=\"width: 666.969px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px; background-color: rgb(255, 255, 255); margin-bottom: 0px !important;\"><tbody><tr class=\"a-spacing-small po-graphics_coprocessor\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Graphics Coprocessor</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">NVIDIA GeForce RTX 3060</span></td></tr><tr class=\"a-spacing-small po-brand\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Brand</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">GIGABYTE</span></td></tr><tr class=\"a-spacing-small po-graphics_ram.size\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Graphics Ram Size</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">12 GB</span></td></tr><tr class=\"a-spacing-small po-gpu_clock_speed\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">GPU Clock Speed</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">1837 MHz</span></td></tr><tr class=\"a-spacing-small po-video_output_interface\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-end: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Video Output Interface</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; padding-block-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">DisplayPort, HDMI</span></td></tr></tbody></table>', '', '<div class=\"a-section table-padding\" style=\"margin-bottom: 22px; margin-left: 12px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\">DigitalWorld.com Return Policy:<span class=\"a-letter-space\" style=\"display: inline-block; width: 0.385em;\"></span>You may return any new computer purchased from DigitalWorld.com that is \"dead on arrival,\" arrives in damaged condition, or is still in unopened boxes, for a full refund within 30 days of purchase. DigitalWorld.com reserves the right to test \"dead on arrival\" returns and impose a customer fee equal to 15 percent of the product sales price if the customer misrepresents the condition of the product. Any returned computer that is damaged through customer misuse, is missing parts, or is in unsellable condition due to customer tampering will result in the customer being charged a higher restocking fee based on the condition of the product. Amazon.com will not accept returns of any desktop or notebook computer more than 30 days after you receive the shipment. New, used, and refurbished products purchased from Marketplace vendors are subject to the returns policy of the individual vendor.<table id=\"productDetails_warranty_support_sections\" class=\"a-keyvalue prodDetTable\" role=\"presentation\" style=\"margin-bottom: 22px; width: 704.594px; border-bottom: 1px solid rgb(213, 217, 217); table-layout: fixed; padding: 0px;\"></table></div><div class=\"a-section table-padding\" style=\"margin-bottom: 0px; margin-left: 12px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\">Manufacturer’s warranty can be requested from customer service.&nbsp;<a href=\"https://www.amazon.com/gp/help/customer/display.html/ref=help_search_1-1?nodeId=201596310\" target=\"_blank\" style=\"color: rgb(33, 98, 161); font-family: Arial;\">Click here</a>&nbsp;to make a request to customer service.</div>', 3, 0, 1, 116);
INSERT INTO `tbl_product` (`p_id`, `p_name`, `p_old_price`, `p_current_price`, `p_qty`, `p_featured_photo`, `p_description`, `p_short_description`, `p_feature`, `p_condition`, `p_return_policy`, `p_total_view`, `p_is_featured`, `p_is_active`, `ecat_id`) VALUES
(121, 'EVGA 06G-P4-2068-KR GeForce RTX 2060 KO Ultra Gaming', '349.99', '320', 8, 'product-featured-121.jpg', '<ul class=\"a-unordered-list a-vertical a-spacing-mini\" style=\"margin-right: 0px; margin-bottom: 0px; margin-left: 18px; color: rgb(15, 17, 17); padding: 0px; font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\"><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Real Boost Clock: 1680 MHz; Memory detail: 6144 MB GDDR6</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Real-Time ray tracing in games for cutting-edge, hyper-realistic graphics</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Dual fans offer higher performance cooling and much quieter acoustic noise.</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Built for EVGA precision X1 all-metal backplate, pre-installed.Avoid using unofficial software</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">3 year &amp; EVGA\'s top notch technical support.</span></li></ul>', '<div id=\"productDescription_feature_div\" class=\"celwidget pd_rd_w-f8kxT pd_rd_r-P9B7ZVD0VS10H0F595XT pd_rd_wg-bGctT\" data-feature-name=\"productDescription\" data-csa-c-type=\"widget\" data-csa-c-content-id=\"productDescription\" data-csa-c-slot-id=\"productDescription_feature_div\" data-csa-c-asin=\"\" data-csa-c-is-in-initial-active-row=\"false\" data-csa-c-id=\"5lo265-8ydaoj-hdnpxx-qq51xb\" data-cel-widget=\"productDescription_feature_div\" style=\"color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\"><div data-feature-name=\"productDescription\" data-template-name=\"productDescription\" id=\"productDescription_feature_div\" class=\"a-row feature\" data-cel-widget=\"productDescription_feature_div\" style=\"width: 1464px;\"><div id=\"productDescription\" class=\"a-section a-spacing-small\" style=\"margin: 0.5em 0px 0em 25px; color: rgb(51, 51, 51); overflow-wrap: break-word; font-size: small; line-height: initial;\"><p style=\"padding: 0px; margin-top: 0em; margin-bottom: 1em; margin-left: 1em;\">The EVGA GeForce RTX 20-Series Graphics Cards are powered by the all-new NVIDIA Turing architecture to give you incredible new levels of gaming realism, speed, power efficiency, and immersion. With the EVGA GeForce RTX 20-Series gaming cards you get the best gaming experience with next generation graphics performance, ice cold cooling, and advanced overclocking features with the all new EVGA Precision X1 software. The new NVIDIA GeForce RTX GPUs have reinvented graphics and set a new bar for performance. Powered by the new NVIDIA Turing GPU architecture and the revolutionary NVIDI RTX platform, the new graphics cards bring together real-time ray tracing, artificial intelligence, and programmable shading. This is not only a whole new way to experience games - this is the ultimate PC gaming experience.</p></div></div></div><div id=\"postPurchaseWhatsInTheBox_MP_feature_div\" class=\"celwidget pd_rd_w-d0kYy pd_rd_r-P9B7ZVD0VS10H0F595XT pd_rd_wg-bGctT\" data-feature-name=\"postPurchaseWhatsInTheBox_MP\" data-csa-c-type=\"widget\" data-csa-c-content-id=\"postPurchaseWhatsInTheBox_MP\" data-csa-c-slot-id=\"postPurchaseWhatsInTheBox_MP_feature_div\" data-csa-c-asin=\"\" data-csa-c-is-in-initial-active-row=\"false\" data-csa-c-id=\"5mybmy-iytoym-axaynk-n7p2fy\" data-cel-widget=\"postPurchaseWhatsInTheBox_MP_feature_div\" style=\"color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\"><div id=\"whatsInTheBoxDeck\" class=\"a-section a-spacing-base celwidget\" data-csa-c-id=\"4o4xmf-nssobz-u97qt-mdcxzi\" data-cel-widget=\"whatsInTheBoxDeck\" style=\"margin-bottom: 0px;\"><hr aria-hidden=\"true\" class=\"a-divider-normal bucketDivider\" style=\"box-sizing: border-box; line-height: 19px; margin-top: 0px; clear: left; background: 0px 0px !important; border-top-color: rgb(204, 204, 204) !important; height: 44px !important; margin-bottom: -36px !important;\"><h2 style=\"padding: 0px; margin: 0px; padding-block-end: 0.25rem; text-rendering: optimizelegibility; line-height: 32px; font-weight: 700 !important; font-size: 1.25rem !important; color: rgb(15, 17, 17) !important; font-family: &quot;Amazon Ember&quot; !important;\">What\'s in the box</h2><dl id=\"witb-content-list\" class=\"a-definition-list a-vertical a-spacing-none postpurchase-included-components-list-group\" style=\"padding: 0px; margin-right: 0px; margin-left: 18px; margin-bottom: 0px !important;\"><li class=\"postpurchase-included-components-list-item\" style=\"overflow-wrap: break-word;\"><span class=\"a-list-item\">Video Card, Manual</span></li></dl></div></div>', '<table class=\"a-normal a-spacing-micro\" role=\"list\" style=\"width: 666.969px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px; background-color: rgb(255, 255, 255); margin-bottom: 0px !important;\"><tbody><tr class=\"a-spacing-small po-graphics_coprocessor\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Graphics Coprocessor</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">NVIDIA GeForce RTX 2060</span></td></tr><tr class=\"a-spacing-small po-brand\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Brand</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">EVGA</span></td></tr><tr class=\"a-spacing-small po-graphics_ram.size\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Graphics Ram Size</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">6 GB</span></td></tr><tr class=\"a-spacing-small po-video_output_interface\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Video Output Interface</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">HDMI, DisplayPort, DVI</span></td></tr><tr class=\"a-spacing-small po-graphics_processor_manufacturer\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-end: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Graphics Processor Manufacturer</span></td></tr></tbody></table>', '', '<div class=\"a-section table-padding\" style=\"margin-bottom: 22px; margin-left: 12px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\">DigitalWorld.com Return Policy:<span class=\"a-letter-space\" style=\"display: inline-block; width: 0.385em;\"></span>You may return any new computer purchased from DigitalWorld.com that is \"dead on arrival,\" arrives in damaged condition, or is still in unopened boxes, for a full refund within 30 days of purchase. DigitalWorld.com reserves the right to test \"dead on arrival\" returns and impose a customer fee equal to 15 percent of the product sales price if the customer misrepresents the condition of the product. Any returned computer that is damaged through customer misuse, is missing parts, or is in unsellable condition due to customer tampering will result in the customer being charged a higher restocking fee based on the condition of the product. Amazon.com will not accept returns of any desktop or notebook computer more than 30 days after you receive the shipment. New, used, and refurbished products purchased from Marketplace vendors are subject to the returns policy of the individual vendor.<table id=\"productDetails_warranty_support_sections\" class=\"a-keyvalue prodDetTable\" role=\"presentation\" style=\"margin-bottom: 22px; width: 704.594px; border-bottom: 1px solid rgb(213, 217, 217); table-layout: fixed; padding: 0px;\"></table></div><div class=\"a-section table-padding\" style=\"margin-bottom: 0px; margin-left: 12px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\">Manufacturer’s warranty can be requested from customer service.&nbsp;<a href=\"https://www.amazon.com/gp/help/customer/display.html/ref=help_search_1-1?nodeId=201596310\" target=\"_blank\" style=\"color: rgb(33, 98, 161); font-family: Arial;\">Click here</a>&nbsp;to make a request to customer service.</div>', 0, 0, 1, 117),
(122, 'GeForce GTX 1050 Ti Gaming', '', '119.98', 3, 'product-featured-122.jpg', '<ul class=\"a-unordered-list a-vertical a-spacing-mini\" style=\"margin-right: 0px; margin-bottom: 0px; margin-left: 18px; color: rgb(15, 17, 17); padding: 0px; font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\"><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">?High Speed?: Power by new Pascal architecture, matching 768 CUDA Cores and GDDR5 video memory with up to 7008 MHz speed to ensure a smooth gaming and application experience.</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">?Stay Cool?: 9cm low noise fan with 9 custom fan blades, cooperating with wide aluminum fin-stack array heatsink to extract more heat and double distributes it more efficiently, which keep the GPU cooler and running longer.</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">?Low Power Consumption?: This 1050ti graphics card does not require an external power supply, and the product packaging does not include a power cable, just plug and play(Please ensure that your computer already has the driver for this type). About 75W full-load power consumption, 300W minimum PSU recommendation.</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">?Abundant Technology?: Support NVIDIA GeForce Experience, NVIDIA Ansel, NVIDIA G-SYNC, Game Ready Drivers, Microsoft DirectX 12 API, Vulkan API, OpenGL 4.5, HDCP 2.2, NVIDIA GPU Boost 3.0, Multi Monitor.</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">?What You Will Get?1x GTX 1050Ti 4GB graphics card, 2-Year Limited warranty, Before installing the driver, you must uninstall the old driver first, otherwise it may cause the driver installation to fail. You can download the driver for this graphics card directly from the official website. Select the driver corresponding to your computer\'s operating system for download and installation. Alternatively, you can use software that automatically installs drivers for the installation process.</span></li></ul>', '<p>GeForce GTX 1050 Ti Gaming Graphics Card, 4GB GDDR5 128bit 1291MHz DP HDMI DVI-Output GPU, PCI Express 3.0 Support Up to 4K Video Card for Office and PC Gaming</p>', '<table class=\"a-normal a-spacing-micro\" role=\"list\" style=\"width: 666.969px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px; background-color: rgb(255, 255, 255); margin-bottom: 0px !important;\"><tbody><tr class=\"a-spacing-small po-graphics_coprocessor\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Graphics Coprocessor</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">GTX 1050 ti</span></td></tr><tr class=\"a-spacing-small po-brand\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Brand</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">ZER-LON</span></td></tr><tr class=\"a-spacing-small po-graphics_ram.size\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Graphics Ram Size</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">4.00</span></td></tr><tr class=\"a-spacing-small po-video_output_interface\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Video Output Interface</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">DVI, DisplayPort, HDMI</span></td></tr><tr class=\"a-spacing-small po-graphics_processor_manufacturer\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-end: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Graphics Processor Manufacturer</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; padding-block-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">NVID</span></td></tr></tbody></table>', '', '<div class=\"a-section table-padding\" style=\"margin-bottom: 22px; margin-left: 12px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\">DigitalWorld.com Return Policy:<span class=\"a-letter-space\" style=\"display: inline-block; width: 0.385em;\"></span>You may return any new computer purchased from DigitalWorld.com that is \"dead on arrival,\" arrives in damaged condition, or is still in unopened boxes, for a full refund within 30 days of purchase. DigitalWorld.com reserves the right to test \"dead on arrival\" returns and impose a customer fee equal to 15 percent of the product sales price if the customer misrepresents the condition of the product. Any returned computer that is damaged through customer misuse, is missing parts, or is in unsellable condition due to customer tampering will result in the customer being charged a higher restocking fee based on the condition of the product. Amazon.com will not accept returns of any desktop or notebook computer more than 30 days after you receive the shipment. New, used, and refurbished products purchased from Marketplace vendors are subject to the returns policy of the individual vendor.<table id=\"productDetails_warranty_support_sections\" class=\"a-keyvalue prodDetTable\" role=\"presentation\" style=\"margin-bottom: 22px; width: 704.594px; border-bottom: 1px solid rgb(213, 217, 217); table-layout: fixed; padding: 0px;\"></table></div><div class=\"a-section table-padding\" style=\"margin-bottom: 0px; margin-left: 12px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\">Manufacturer’s warranty can be requested from customer service.&nbsp;<a href=\"https://www.amazon.com/gp/help/customer/display.html/ref=help_search_1-1?nodeId=201596310\" target=\"_blank\" style=\"color: rgb(33, 98, 161); font-family: Arial;\">Click here</a>&nbsp;to make a request to customer service.</div>', 0, 0, 1, 118),
(123, 'EVGA GeForce GTX 1650 Super SC Ultra Gaming', '', '320', 1, 'product-featured-123.jpg', '<ul class=\"a-unordered-list a-vertical a-spacing-mini\" style=\"margin-right: 0px; margin-bottom: 0px; margin-left: 18px; color: rgb(15, 17, 17); padding: 0px; font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\"><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Real Boost Clock: 1755 MHz; Memory Detail: 4096 MB GDDR6</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">All-new NVIDIA Turing architecture to give you incredible new levels of gaming realism, speed, power efficiency and immersion</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Dual fans offer higher performance cooling and low acoustic noise</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Built for EVGA Precision x1 All-metal backplate, pre-installed.Avoid using unofficial software</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">3 year &amp; EVGA top notch technical support</span></li></ul>', '<p>EVGA GeForce GTX 1650 Super SC Ultra Gaming, 4GB GDDR6, Dual Fan, Metal Backplate, 04G-P4-1357-KR</p>', '<table class=\"a-normal a-spacing-micro\" role=\"list\" style=\"width: 666.969px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px; background-color: rgb(255, 255, 255); margin-bottom: 0px !important;\"><tbody><tr class=\"a-spacing-small po-graphics_coprocessor\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Graphics Coprocessor</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">NVIDIA GeForce GTX 1650</span></td></tr><tr class=\"a-spacing-small po-brand\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Brand</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">EVGA</span></td></tr><tr class=\"a-spacing-small po-graphics_ram.size\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Graphics Ram Size</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">4 GB</span></td></tr><tr class=\"a-spacing-small po-video_output_interface\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Video Output Interface</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">HDMI</span></td></tr><tr class=\"a-spacing-small po-graphics_processor_manufacturer\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-end: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Graphics Processor Manufacturer</span></td></tr></tbody></table>', '<div class=\"a-section table-padding\" style=\"margin-bottom: 22px; margin-left: 12px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\">DigitalWorld.com Return Policy:<span class=\"a-letter-space\" style=\"display: inline-block; width: 0.385em;\"></span>You may return any new computer purchased from DigitalWorld.com that is \"dead on arrival,\" arrives in damaged condition, or is still in unopened boxes, for a full refund within 30 days of purchase. DigitalWorld.com reserves the right to test \"dead on arrival\" returns and impose a customer fee equal to 15 percent of the product sales price if the customer misrepresents the condition of the product. Any returned computer that is damaged through customer misuse, is missing parts, or is in unsellable condition due to customer tampering will result in the customer being charged a higher restocking fee based on the condition of the product. Amazon.com will not accept returns of any desktop or notebook computer more than 30 days after you receive the shipment. New, used, and refurbished products purchased from Marketplace vendors are subject to the returns policy of the individual vendor.<table id=\"productDetails_warranty_support_sections\" class=\"a-keyvalue prodDetTable\" role=\"presentation\" style=\"margin-bottom: 22px; width: 704.594px; border-bottom: 1px solid rgb(213, 217, 217); table-layout: fixed; padding: 0px;\"></table></div><div class=\"a-section table-padding\" style=\"margin-bottom: 0px; margin-left: 12px; color: rgb(15, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\">Manufacturer’s warranty can be requested from customer service.&nbsp;<a href=\"https://www.amazon.com/gp/help/customer/display.html/ref=help_search_1-1?nodeId=201596310\" target=\"_blank\" style=\"color: rgb(33, 98, 161); font-family: Arial;\">Click here</a>&nbsp;to make a request to customer service.</div>', '', 0, 0, 1, 119),
(124, 'Radeon RX 5700 XT 8GB', '', '209.99', 1, 'product-featured-124.jpg', '<ul class=\"a-unordered-list a-vertical a-spacing-mini\" style=\"margin-right: 0px; margin-bottom: 0px; margin-left: 18px; color: rgb(15, 17, 17); padding: 0px; font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px;\"><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Exceptional GPU Performance: The Mllse RX 5700 XT graphics card is equipped with 2560 CUDA cores, which are capable of executing multiple instructions simultaneously, delivering superior gaming, and streaming performance. The powerful Navi 10 GPU architecture provides stable and smooth gameplay, even in the most demanding environments.</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Cutting-Edge Technology: The RX 5700 XT’s advanced 7nm core technology ensures exceptional performance and efficiency while reducing power consumption. This technology provides improved performance per watt, enabling you to play games for longer while maintaining optimal performance.</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">High-Quality VRAM: Video memory is vital for any graphics card, especially in gaming. The RX 5700 XT is equipped with 8GB of high-speed GDDR6 memory, offering improved data transfer speeds and superior visual quality. The card also features a 256-bit memory interface, which enables faster data transmission and lower latency.</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">Efficient Power Consumption: The RX 5700 XT is built with energy efficiency in mind, making it an eco-friendly and budget-friendly gaming solution. The card is designed to use less power than previous models, allowing you to play games for longer without worrying about energy consumption. The recommended power supply is 600 watts or above, and power is supplied via a 6Pin+8Pin power interface.</span></li><li class=\"a-spacing-mini\" style=\"list-style: disc; overflow-wrap: break-word; margin: 0px;\"><span class=\"a-list-item\">User-friendly Design: The RX 5700 XT is perfect for gamers who want high-quality performance. The card measures only 9.0 x4.37x1.97inch, making it compatible with most desktops. It is also easy to install and use, with straightforward installation procedures and a user-friendly interface. The PCI-e 4.0 x16 compatibility ensures that the card is compatible with the latest motherboards and offers optimal data transmission speeds.</span></li></ul>', '<p>RX 5700 XT Graphics Card, Radeon RX 5700 XT 8GB GDDR6 2560SP 256bit PCI-e 4.0 x16 GPU Computer Video Card, HDMI/DisplayPort*3 Interface, 2K 4K Game Card for Desktop PC</p>', '<table class=\"a-normal a-spacing-micro\" role=\"list\" style=\"width: 666.969px; color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px; background-color: rgb(255, 255, 255); margin-bottom: 0px !important;\"><tbody><tr class=\"a-spacing-small po-graphics_coprocessor\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Graphics Coprocessor</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; padding-block-start: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">AMD Radeon RX 5700 XT</span></td></tr><tr class=\"a-spacing-small po-brand\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Brand</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">Mllse</span></td></tr><tr class=\"a-spacing-small po-graphics_ram.size\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Graphics Ram Size</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">8 GB</span></td></tr><tr class=\"a-spacing-small po-video_output_interface\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Video Output Interface</span></td><td class=\"a-span9\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 492.359px; padding-inline-end: 0px; float: none !important;\"><span class=\"a-size-base po-break-word\" style=\"word-break: break-word; line-height: 20px !important;\">DisplayPort, HDMI</span></td></tr><tr class=\"a-spacing-small po-graphics_processor_manufacturer\" role=\"listitem\" style=\"margin-bottom: 8px !important;\"><td class=\"a-span3\" role=\"presentation\" style=\"padding: 0.1875rem; vertical-align: top; margin-right: 0px; width: 174.609px; padding-inline-start: 0px; padding-block-end: 0px; float: none !important;\"><span class=\"a-size-base a-text-bold\" style=\"font-weight: 700 !important; line-height: 20px !important;\">Graphics Processor Manufacturer</span></td></tr></tbody></table>', '', '<div class=\"a-section table-padding\" style=\"margin-bottom: 22px; margin-left: 12px; color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px;\">DigitalWorld.com Return Policy:<span class=\"a-letter-space\" style=\"display: inline-block; width: 0.385em;\"></span>You may return any new computer purchased from DigitalWorld.com that is \"dead on arrival,\" arrives in damaged condition, or is still in unopened boxes, for a full refund within 30 days of purchase. DigitalWorld.com reserves the right to test \"dead on arrival\" returns and impose a customer fee equal to 15 percent of the product sales price if the customer misrepresents the condition of the product. Any returned computer that is damaged through customer misuse, is missing parts, or is in unsellable condition due to customer tampering will result in the customer being charged a higher restocking fee based on the condition of the product. Amazon.com will not accept returns of any desktop or notebook computer more than 30 days after you receive the shipment. New, used, and refurbished products purchased from Marketplace vendors are subject to the returns policy of the individual vendor.<table id=\"productDetails_warranty_support_sections\" class=\"a-keyvalue prodDetTable\" role=\"presentation\" style=\"margin-bottom: 22px; width: 704.594px; border-bottom: 1px solid rgb(213, 217, 217); table-layout: fixed; padding: 0px;\"></table></div><div class=\"a-section table-padding\" style=\"margin-bottom: 0px; margin-left: 12px; color: rgb(15, 17, 17); font-family: \"Amazon Ember\", Arial, sans-serif; font-size: 14px;\">Manufacturer’s warranty can be requested from customer service. <a href=\"https://www.amazon.com/gp/help/customer/display.html/ref=help_search_1-1?nodeId=201596310\" target=\"_blank\" style=\"color: rgb(33, 98, 161); font-family: Arial;\">Click here</a> to make a request to customer service.</div>', 9, 0, 1, 123);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_product_color`
--

CREATE TABLE `tbl_product_color` (
  `id` int(11) NOT NULL,
  `color_id` int(11) NOT NULL,
  `p_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Volcado de datos para la tabla `tbl_product_color`
--

INSERT INTO `tbl_product_color` (`id`, `color_id`, `p_id`) VALUES
(69, 1, 4),
(70, 4, 4),
(77, 6, 6),
(82, 2, 12),
(83, 9, 13),
(84, 3, 14),
(85, 2, 15),
(86, 6, 15),
(87, 3, 16),
(88, 3, 17),
(89, 2, 18),
(90, 3, 19),
(91, 1, 20),
(92, 8, 21),
(93, 2, 22),
(94, 2, 23),
(95, 2, 25),
(96, 5, 26),
(97, 2, 27),
(98, 4, 27),
(99, 5, 28),
(100, 7, 29),
(101, 10, 30),
(102, 11, 31),
(103, 14, 32),
(105, 2, 34),
(106, 1, 35),
(107, 3, 36),
(109, 6, 38),
(110, 2, 39),
(111, 11, 42),
(149, 3, 10),
(150, 6, 9),
(151, 3, 8),
(152, 7, 7),
(159, 2, 77),
(163, 17, 79),
(164, 2, 78),
(167, 3, 80),
(168, 2, 81),
(172, 1, 82),
(173, 2, 82),
(174, 4, 82);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_product_photo`
--

CREATE TABLE `tbl_product_photo` (
  `pp_id` int(11) NOT NULL,
  `photo` varchar(191) NOT NULL,
  `p_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Volcado de datos para la tabla `tbl_product_photo`
--

INSERT INTO `tbl_product_photo` (`pp_id`, `photo`, `p_id`) VALUES
(134, '134.jpg', 115),
(135, '135.jpg', 118);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_product_size`
--

CREATE TABLE `tbl_product_size` (
  `id` int(11) NOT NULL,
  `size_id` int(11) NOT NULL,
  `p_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Volcado de datos para la tabla `tbl_product_size`
--

INSERT INTO `tbl_product_size` (`id`, `size_id`, `p_id`) VALUES
(44, 1, 6),
(56, 8, 12),
(57, 9, 12),
(58, 10, 12),
(59, 11, 12),
(60, 12, 12),
(61, 13, 12),
(62, 9, 13),
(63, 11, 13),
(64, 13, 13),
(65, 15, 13),
(66, 9, 14),
(67, 11, 14),
(68, 12, 14),
(69, 13, 14),
(70, 9, 15),
(71, 11, 15),
(72, 13, 15),
(73, 15, 16),
(74, 16, 16),
(75, 17, 16),
(76, 16, 17),
(77, 17, 17),
(78, 14, 18),
(79, 15, 18),
(80, 16, 18),
(81, 17, 18),
(82, 15, 19),
(83, 16, 19),
(84, 17, 19),
(85, 14, 20),
(86, 15, 20),
(87, 17, 20),
(88, 15, 21),
(89, 17, 21),
(90, 15, 22),
(91, 16, 22),
(92, 17, 22),
(93, 15, 23),
(94, 16, 23),
(95, 17, 23),
(96, 18, 25),
(97, 19, 25),
(98, 20, 25),
(99, 21, 25),
(100, 19, 26),
(101, 21, 26),
(102, 22, 26),
(103, 23, 26),
(104, 19, 27),
(105, 20, 27),
(106, 21, 27),
(107, 22, 27),
(108, 19, 28),
(109, 20, 28),
(110, 21, 28),
(111, 19, 29),
(112, 20, 29),
(113, 22, 29),
(114, 1, 30),
(115, 2, 30),
(116, 3, 30),
(117, 4, 30),
(118, 23, 31),
(119, 26, 32),
(123, 2, 34),
(124, 2, 35),
(125, 2, 36),
(126, 3, 36),
(129, 2, 38),
(130, 3, 38),
(131, 4, 38),
(132, 5, 38),
(133, 27, 39),
(134, 8, 42),
(210, 3, 10),
(211, 4, 10),
(212, 5, 10),
(213, 6, 10),
(214, 3, 9),
(215, 4, 9),
(216, 3, 8),
(217, 4, 8),
(218, 2, 7),
(219, 3, 7),
(220, 4, 7),
(249, 1, 79),
(250, 2, 79),
(251, 3, 79),
(252, 1, 78),
(253, 2, 78),
(254, 3, 78),
(255, 4, 78),
(256, 5, 78),
(259, 26, 80),
(262, 3, 82),
(263, 4, 82);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_rating`
--

CREATE TABLE `tbl_rating` (
  `rt_id` int(11) NOT NULL,
  `p_id` int(11) NOT NULL,
  `cust_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `rating` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_service`
--

CREATE TABLE `tbl_service` (
  `id` int(11) NOT NULL,
  `title` varchar(191) NOT NULL,
  `content` text NOT NULL,
  `photo` varchar(191) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_settings`
--

CREATE TABLE `tbl_settings` (
  `id` int(11) NOT NULL,
  `logo` varchar(191) NOT NULL,
  `favicon` varchar(191) NOT NULL,
  `footer_about` text NOT NULL,
  `footer_copyright` text NOT NULL,
  `contact_address` text NOT NULL,
  `contact_email` varchar(191) NOT NULL,
  `contact_phone` varchar(191) NOT NULL,
  `contact_fax` varchar(191) NOT NULL,
  `contact_map_iframe` text NOT NULL,
  `receive_email` varchar(191) NOT NULL,
  `receive_email_subject` varchar(191) NOT NULL,
  `receive_email_thank_you_message` text NOT NULL,
  `forget_password_message` text NOT NULL,
  `total_recent_post_footer` int(10) NOT NULL,
  `total_popular_post_footer` int(10) NOT NULL,
  `total_recent_post_sidebar` int(11) NOT NULL,
  `total_popular_post_sidebar` int(11) NOT NULL,
  `total_featured_product_home` int(11) NOT NULL,
  `total_latest_product_home` int(11) NOT NULL,
  `total_popular_product_home` int(11) NOT NULL,
  `meta_title_home` text NOT NULL,
  `meta_keyword_home` text NOT NULL,
  `meta_description_home` text NOT NULL,
  `banner_login` varchar(191) NOT NULL,
  `banner_registration` varchar(191) NOT NULL,
  `banner_forget_password` varchar(191) NOT NULL,
  `banner_reset_password` varchar(191) NOT NULL,
  `banner_search` varchar(191) NOT NULL,
  `banner_cart` varchar(191) NOT NULL,
  `banner_checkout` varchar(191) NOT NULL,
  `banner_product_category` varchar(191) NOT NULL,
  `banner_blog` varchar(191) NOT NULL,
  `cta_title` varchar(191) NOT NULL,
  `cta_content` text NOT NULL,
  `cta_read_more_text` varchar(191) NOT NULL,
  `cta_read_more_url` varchar(191) NOT NULL,
  `cta_photo` varchar(191) NOT NULL,
  `featured_product_title` varchar(191) NOT NULL,
  `featured_product_subtitle` varchar(191) NOT NULL,
  `latest_product_title` varchar(191) NOT NULL,
  `latest_product_subtitle` varchar(191) NOT NULL,
  `popular_product_title` varchar(191) NOT NULL,
  `popular_product_subtitle` varchar(191) NOT NULL,
  `testimonial_title` varchar(191) NOT NULL,
  `testimonial_subtitle` varchar(191) NOT NULL,
  `testimonial_photo` varchar(191) NOT NULL,
  `blog_title` varchar(191) NOT NULL,
  `blog_subtitle` varchar(191) NOT NULL,
  `newsletter_text` text NOT NULL,
  `paypal_email` varchar(191) NOT NULL,
  `stripe_public_key` varchar(191) NOT NULL,
  `stripe_secret_key` varchar(191) NOT NULL,
  `bank_detail` text NOT NULL,
  `before_head` text NOT NULL,
  `after_body` text NOT NULL,
  `before_body` text NOT NULL,
  `home_service_on_off` int(11) NOT NULL,
  `home_welcome_on_off` int(11) NOT NULL,
  `home_featured_product_on_off` int(11) NOT NULL,
  `home_latest_product_on_off` int(11) NOT NULL,
  `home_popular_product_on_off` int(11) NOT NULL,
  `home_testimonial_on_off` int(11) NOT NULL,
  `home_blog_on_off` int(11) NOT NULL,
  `newsletter_on_off` int(11) NOT NULL,
  `ads_above_welcome_on_off` int(1) NOT NULL,
  `ads_above_featured_product_on_off` int(1) NOT NULL,
  `ads_above_latest_product_on_off` int(1) NOT NULL,
  `ads_above_popular_product_on_off` int(1) NOT NULL,
  `ads_above_testimonial_on_off` int(1) NOT NULL,
  `ads_category_sidebar_on_off` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Volcado de datos para la tabla `tbl_settings`
--

INSERT INTO `tbl_settings` (`id`, `logo`, `favicon`, `footer_about`, `footer_copyright`, `contact_address`, `contact_email`, `contact_phone`, `contact_fax`, `contact_map_iframe`, `receive_email`, `receive_email_subject`, `receive_email_thank_you_message`, `forget_password_message`, `total_recent_post_footer`, `total_popular_post_footer`, `total_recent_post_sidebar`, `total_popular_post_sidebar`, `total_featured_product_home`, `total_latest_product_home`, `total_popular_product_home`, `meta_title_home`, `meta_keyword_home`, `meta_description_home`, `banner_login`, `banner_registration`, `banner_forget_password`, `banner_reset_password`, `banner_search`, `banner_cart`, `banner_checkout`, `banner_product_category`, `banner_blog`, `cta_title`, `cta_content`, `cta_read_more_text`, `cta_read_more_url`, `cta_photo`, `featured_product_title`, `featured_product_subtitle`, `latest_product_title`, `latest_product_subtitle`, `popular_product_title`, `popular_product_subtitle`, `testimonial_title`, `testimonial_subtitle`, `testimonial_photo`, `blog_title`, `blog_subtitle`, `newsletter_text`, `paypal_email`, `stripe_public_key`, `stripe_secret_key`, `bank_detail`, `before_head`, `after_body`, `before_body`, `home_service_on_off`, `home_welcome_on_off`, `home_featured_product_on_off`, `home_latest_product_on_off`, `home_popular_product_on_off`, `home_testimonial_on_off`, `home_blog_on_off`, `newsletter_on_off`, `ads_above_welcome_on_off`, `ads_above_featured_product_on_off`, `ads_above_latest_product_on_off`, `ads_above_popular_product_on_off`, `ads_above_testimonial_on_off`, `ads_category_sidebar_on_off`) VALUES
(1, 'logo.jpg', 'favicon.jpg', '<p>Lorem ipsum dolor sit amet, omnis signiferumque in mei, mei ex enim concludaturque. Senserit salutandi euripidis no per, modus maiestatis scribentur est an.Â Ea suas pertinax has.</p>\r\n', 'Copyright © 2025 - Beiker Company', '', 'support@digitalworld.com', '+503 78785555', '', '<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3876.6152179952837!2d-89.23844792411316!3d13.681145798923898!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8f6331cd305c735b%3A0x3d2a75b3761d4ded!2sUniversidad%20Centroamericana%20Jos%C3%A9%20Sime%C3%B3n%20Ca%C3%B1as!5e0!3m2!1ses-419!2ssv!4v1761635204665!5m2!1ses-419!2ssv\" width=\"600\" height=\"450\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\" referrerpolicy=\"no-referrer-when-downgrade\"></iframe>', 'support@digitalworld.com', 'Visitor Email Message from Digital World', 'Thank you for sending email. We will contact you shortly.', 'A confirmation link is sent to your email address. You will get the password reset information in there.', 4, 4, 5, 5, 5, 6, 8, 'DIGITAL WORLD', 'online computer\'s store', '', 'banner_login.jpg', 'banner_registration.jpg', 'banner_forget_password.jpg', 'banner_reset_password.jpg', 'banner_search.jpg', 'banner_cart.jpg', 'banner_checkout.jpg', 'banner_product_category.jpg', 'banner_blog.jpg', 'Welcome To Our Ecommerce Website', 'Lorem ipsum dolor sit amet, an labores explicari qui, eu nostrum copiosae argumentum has. Latine propriae quo no, unum ridens expetenda id sit, \r\nat usu eius eligendi singulis. Sea ocurreret principes ne. At nonumy aperiri pri, nam quodsi copiosae intellegebat et, ex deserunt euripidis usu. ', 'Read More', '#', 'cta.jpg', 'Featured Products', 'Our list on Top Featured Products', 'Latest Products', 'Our list of recently added products', 'Popular Products', 'Popular products based on customer\'s choice', 'Testimonials', 'See what our clients tell about us', 'testimonial.jpg', 'Latest Blog', 'See all our latest articles and news from below', 'Sign-up to our newsletter for latest promotions and discounts.', 'admin@digitalworld.com', 'pk_test_0SwMWadgu8DwmEcPdUPRsZ7b', 'sk_test_TFcsLJ7xxUtpALbDo1L5c1PN', 'Bank Name: Cuscatlan\r\nAccount Number: 100270589600\r\nCountry: ESA', '', '<div id=\"fb-root\"></div>\r\n<script>(function(d, s, id) {\r\n  var js, fjs = d.getElementsByTagName(s)[0];\r\n  if (d.getElementById(id)) return;\r\n  js = d.createElement(s); js.id = id;\r\n  js.src = \"//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.10&appId=323620764400430\";\r\n  fjs.parentNode.insertBefore(js, fjs);\r\n}(document, \'script\', \'facebook-jssdk\'));</script>', '', 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_shipping_cost`
--

CREATE TABLE `tbl_shipping_cost` (
  `shipping_cost_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `amount` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Volcado de datos para la tabla `tbl_shipping_cost`
--

INSERT INTO `tbl_shipping_cost` (`shipping_cost_id`, `country_id`, `amount`) VALUES
(1, 228, '11'),
(2, 167, '10'),
(3, 13, '8'),
(4, 230, '0'),
(5, 63, '0');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_shipping_cost_all`
--

CREATE TABLE `tbl_shipping_cost_all` (
  `sca_id` int(11) NOT NULL,
  `amount` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Volcado de datos para la tabla `tbl_shipping_cost_all`
--

INSERT INTO `tbl_shipping_cost_all` (`sca_id`, `amount`) VALUES
(1, '100');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_size`
--

CREATE TABLE `tbl_size` (
  `size_id` int(11) NOT NULL,
  `size_name` varchar(191) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Volcado de datos para la tabla `tbl_size`
--

INSERT INTO `tbl_size` (`size_id`, `size_name`) VALUES
(1, 'XS'),
(2, 'S'),
(3, 'M'),
(4, 'L'),
(5, 'XL'),
(6, 'XXL'),
(7, '3XL'),
(8, '31'),
(9, '32'),
(10, '33'),
(11, '34'),
(12, '35'),
(13, '36'),
(14, '37'),
(15, '38'),
(16, '39'),
(17, '40'),
(18, '41'),
(19, '42'),
(20, '43'),
(21, '44'),
(22, '45'),
(23, '46'),
(24, '47'),
(25, '48'),
(26, 'Free Size'),
(27, 'One Size for All'),
(28, '10'),
(29, '12 Months'),
(30, '2T'),
(31, '3T'),
(32, '4T'),
(33, '5T'),
(34, '6 Years'),
(35, '7 Years'),
(36, '8 Years'),
(37, '10 Years'),
(38, '12 Years'),
(39, '14 Years'),
(40, '256 GB'),
(41, '128 GB'),
(42, '14 Plus'),
(43, '16 Plus'),
(44, '18 Plus'),
(45, '20 Plus'),
(46, '22 Plus'),
(47, '24 Plus');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_slider`
--

CREATE TABLE `tbl_slider` (
  `id` int(11) NOT NULL,
  `photo` varchar(191) NOT NULL,
  `heading` varchar(191) NOT NULL,
  `content` text NOT NULL,
  `button_text` varchar(191) NOT NULL,
  `button_url` varchar(191) NOT NULL,
  `position` varchar(191) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Volcado de datos para la tabla `tbl_slider`
--

INSERT INTO `tbl_slider` (`id`, `photo`, `heading`, `content`, `button_text`, `button_url`, `position`) VALUES
(2, 'slider-2.png', '50% Discount on All Products', 'BLACK FRIDAY DISCOUNTS', 'Read More', 'http://localhost/Proyecto_Final_PW_Seccion01/eCommerceSite-PHP/product-category.php?id=2&type=top-category', 'Center'),
(3, 'slider-3.png', '24 Hours Customer Support', 'With us you\'ll have the best support in the digital world', 'Read More', '#', 'Right'),
(4, 'slider-4.jpg', 'The Best Computers of the world', 'Don\'t miss the best promotion just in Digital World', 'Purchase Here!', '', 'Center');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_social`
--

CREATE TABLE `tbl_social` (
  `social_id` int(11) NOT NULL,
  `social_name` varchar(30) NOT NULL,
  `social_url` varchar(191) NOT NULL,
  `social_icon` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Volcado de datos para la tabla `tbl_social`
--

INSERT INTO `tbl_social` (`social_id`, `social_name`, `social_url`, `social_icon`) VALUES
(1, 'Facebook', 'https://www.facebook.com/#', 'fa fa-facebook'),
(2, 'Twitter', 'https://www.twitter.com/#', 'fa fa-twitter'),
(3, 'LinkedIn', '', 'fa fa-linkedin'),
(4, 'Google Plus', '', 'fa fa-google-plus'),
(5, 'Pinterest', '', 'fa fa-pinterest'),
(6, 'YouTube', 'https://www.youtube.com/#', 'fa fa-youtube'),
(7, 'Instagram', 'https://www.instagram.com/#', 'fa fa-instagram'),
(8, 'Tumblr', '', 'fa fa-tumblr'),
(9, 'Flickr', '', 'fa fa-flickr'),
(10, 'Reddit', '', 'fa fa-reddit'),
(11, 'Snapchat', '', 'fa fa-snapchat'),
(12, 'WhatsApp', 'https://www.whatsapp.com/#', 'fa fa-whatsapp'),
(13, 'Quora', '', 'fa fa-quora'),
(14, 'StumbleUpon', '', 'fa fa-stumbleupon'),
(15, 'Delicious', '', 'fa fa-delicious'),
(16, 'Digg', '', 'fa fa-digg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_subscriber`
--

CREATE TABLE `tbl_subscriber` (
  `subs_id` int(11) NOT NULL,
  `subs_email` varchar(191) NOT NULL,
  `subs_date` varchar(100) NOT NULL,
  `subs_date_time` varchar(100) NOT NULL,
  `subs_hash` varchar(191) NOT NULL,
  `subs_active` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Volcado de datos para la tabla `tbl_subscriber`
--

INSERT INTO `tbl_subscriber` (`subs_id`, `subs_email`, `subs_date`, `subs_date_time`, `subs_hash`, `subs_active`) VALUES
(9, 'hjosealfredo2012@gmail.com', '2025-11-26', '2025-11-26 18:41:30', '9e7643f41d4258f83b0ac15cb8c36f16', 0),
(10, 'hjosealfredo55@gmail.com', '2025-11-26', '2025-11-26 18:42:26', '9e1e1e8f3b0da08748f49bda73f98280', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_top_category`
--

CREATE TABLE `tbl_top_category` (
  `tcat_id` int(11) NOT NULL,
  `tcat_name` varchar(191) NOT NULL,
  `show_on_menu` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Volcado de datos para la tabla `tbl_top_category`
--

INSERT INTO `tbl_top_category` (`tcat_id`, `tcat_name`, `show_on_menu`) VALUES
(1, 'Graphics Cards', 1),
(2, 'Laptop', 1),
(3, 'Desktop Computers', 1),
(6, 'Processor\'s', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(10) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(191) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `password` varchar(191) NOT NULL,
  `photo` varchar(191) NOT NULL,
  `role` varchar(30) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Volcado de datos para la tabla `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `full_name`, `email`, `phone`, `password`, `photo`, `role`, `status`) VALUES
(1, 'Administrator', 'admin@mail.com', '7777777777', 'd00f5d5217896fb7fd601412cb890830', 'user-1.png', 'Super Admin', 'Active'),
(2, 'Christine', 'christine@mail.com', '4444444444', '81dc9bdb52d04dc20036dbd8313ed055', 'user-13.jpg', 'Admin', 'Active');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_video`
--

CREATE TABLE `tbl_video` (
  `id` int(11) NOT NULL,
  `title` varchar(191) NOT NULL,
  `iframe_code` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Volcado de datos para la tabla `tbl_video`
--

INSERT INTO `tbl_video` (`id`, `title`, `iframe_code`) VALUES
(1, 'Video 1', '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/L3XAFSMdVWU\" frameborder=\"0\" allow=\"autoplay; encrypted-media\" allowfullscreen></iframe>'),
(2, 'Video 2', '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/sinQ06YzbJI\" frameborder=\"0\" allow=\"autoplay; encrypted-media\" allowfullscreen></iframe>'),
(4, 'Video 3', '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/ViZNgU-Yt-Y\" frameborder=\"0\" allow=\"autoplay; encrypted-media\" allowfullscreen></iframe>');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `tbl_color`
--
ALTER TABLE `tbl_color`
  ADD PRIMARY KEY (`color_id`);

--
-- Indices de la tabla `tbl_country`
--
ALTER TABLE `tbl_country`
  ADD PRIMARY KEY (`country_id`);

--
-- Indices de la tabla `tbl_customer`
--
ALTER TABLE `tbl_customer`
  ADD PRIMARY KEY (`cust_id`);

--
-- Indices de la tabla `tbl_customer_message`
--
ALTER TABLE `tbl_customer_message`
  ADD PRIMARY KEY (`customer_message_id`);

--
-- Indices de la tabla `tbl_end_category`
--
ALTER TABLE `tbl_end_category`
  ADD PRIMARY KEY (`ecat_id`);

--
-- Indices de la tabla `tbl_faq`
--
ALTER TABLE `tbl_faq`
  ADD PRIMARY KEY (`faq_id`);

--
-- Indices de la tabla `tbl_language`
--
ALTER TABLE `tbl_language`
  ADD PRIMARY KEY (`lang_id`);

--
-- Indices de la tabla `tbl_mid_category`
--
ALTER TABLE `tbl_mid_category`
  ADD PRIMARY KEY (`mcat_id`);

--
-- Indices de la tabla `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tbl_page`
--
ALTER TABLE `tbl_page`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tbl_payment`
--
ALTER TABLE `tbl_payment`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tbl_photo`
--
ALTER TABLE `tbl_photo`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tbl_post`
--
ALTER TABLE `tbl_post`
  ADD PRIMARY KEY (`post_id`);

--
-- Indices de la tabla `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`p_id`);

--
-- Indices de la tabla `tbl_product_color`
--
ALTER TABLE `tbl_product_color`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tbl_product_photo`
--
ALTER TABLE `tbl_product_photo`
  ADD PRIMARY KEY (`pp_id`);

--
-- Indices de la tabla `tbl_product_size`
--
ALTER TABLE `tbl_product_size`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tbl_rating`
--
ALTER TABLE `tbl_rating`
  ADD PRIMARY KEY (`rt_id`);

--
-- Indices de la tabla `tbl_service`
--
ALTER TABLE `tbl_service`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tbl_settings`
--
ALTER TABLE `tbl_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tbl_shipping_cost`
--
ALTER TABLE `tbl_shipping_cost`
  ADD PRIMARY KEY (`shipping_cost_id`);

--
-- Indices de la tabla `tbl_shipping_cost_all`
--
ALTER TABLE `tbl_shipping_cost_all`
  ADD PRIMARY KEY (`sca_id`);

--
-- Indices de la tabla `tbl_size`
--
ALTER TABLE `tbl_size`
  ADD PRIMARY KEY (`size_id`);

--
-- Indices de la tabla `tbl_slider`
--
ALTER TABLE `tbl_slider`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tbl_social`
--
ALTER TABLE `tbl_social`
  ADD PRIMARY KEY (`social_id`);

--
-- Indices de la tabla `tbl_subscriber`
--
ALTER TABLE `tbl_subscriber`
  ADD PRIMARY KEY (`subs_id`);

--
-- Indices de la tabla `tbl_top_category`
--
ALTER TABLE `tbl_top_category`
  ADD PRIMARY KEY (`tcat_id`);

--
-- Indices de la tabla `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tbl_video`
--
ALTER TABLE `tbl_video`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `tbl_color`
--
ALTER TABLE `tbl_color`
  MODIFY `color_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT de la tabla `tbl_country`
--
ALTER TABLE `tbl_country`
  MODIFY `country_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=246;

--
-- AUTO_INCREMENT de la tabla `tbl_customer`
--
ALTER TABLE `tbl_customer`
  MODIFY `cust_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT de la tabla `tbl_customer_message`
--
ALTER TABLE `tbl_customer_message`
  MODIFY `customer_message_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `tbl_end_category`
--
ALTER TABLE `tbl_end_category`
  MODIFY `ecat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=124;

--
-- AUTO_INCREMENT de la tabla `tbl_faq`
--
ALTER TABLE `tbl_faq`
  MODIFY `faq_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `tbl_language`
--
ALTER TABLE `tbl_language`
  MODIFY `lang_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=164;

--
-- AUTO_INCREMENT de la tabla `tbl_mid_category`
--
ALTER TABLE `tbl_mid_category`
  MODIFY `mcat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT de la tabla `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `tbl_page`
--
ALTER TABLE `tbl_page`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `tbl_payment`
--
ALTER TABLE `tbl_payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT de la tabla `tbl_photo`
--
ALTER TABLE `tbl_photo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `tbl_post`
--
ALTER TABLE `tbl_post`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de la tabla `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=125;

--
-- AUTO_INCREMENT de la tabla `tbl_product_color`
--
ALTER TABLE `tbl_product_color`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=296;

--
-- AUTO_INCREMENT de la tabla `tbl_product_photo`
--
ALTER TABLE `tbl_product_photo`
  MODIFY `pp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=136;

--
-- AUTO_INCREMENT de la tabla `tbl_product_size`
--
ALTER TABLE `tbl_product_size`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=498;

--
-- AUTO_INCREMENT de la tabla `tbl_rating`
--
ALTER TABLE `tbl_rating`
  MODIFY `rt_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tbl_service`
--
ALTER TABLE `tbl_service`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `tbl_settings`
--
ALTER TABLE `tbl_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `tbl_shipping_cost`
--
ALTER TABLE `tbl_shipping_cost`
  MODIFY `shipping_cost_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `tbl_shipping_cost_all`
--
ALTER TABLE `tbl_shipping_cost_all`
  MODIFY `sca_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `tbl_size`
--
ALTER TABLE `tbl_size`
  MODIFY `size_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT de la tabla `tbl_slider`
--
ALTER TABLE `tbl_slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `tbl_social`
--
ALTER TABLE `tbl_social`
  MODIFY `social_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de la tabla `tbl_subscriber`
--
ALTER TABLE `tbl_subscriber`
  MODIFY `subs_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `tbl_top_category`
--
ALTER TABLE `tbl_top_category`
  MODIFY `tcat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `tbl_video`
--
ALTER TABLE `tbl_video`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
